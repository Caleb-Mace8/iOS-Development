//
//  ContentView.swift
//  ButtonsLab
//
//  Created by Caleb Mace on 9/29/25.
//

import SwiftUI

struct ContentView: View {
    
    @State var onePressed = false
    func toggleOne() {
        onePressed.toggle()
    }
    @State var twoPressed = false
    func toggleTwo() {
        twoPressed.toggle()
    }
    @State var threePressed = false
    func toggleThree() {
        threePressed.toggle()
    }
    @State var fourPressed = false
    func toggleFour() {
        fourPressed.toggle()
    }
    @State var fivePressed = false
    func toggleFive() {
        fivePressed.toggle()
    }
    @State var sixPressed = false
    func toggleSix() {
        sixPressed.toggle()
    }
    @State var sevenPressed = false
    func toggleSeven() {
        sevenPressed.toggle()
    }
    @State var eightPressed = false
    func toggleEight() {
        eightPressed.toggle()
    }
    @State var ninePressed = false
    func toggleNine() {
        ninePressed.toggle()
    }
    @State var tenPressed = false
    func toggleTen() {
        tenPressed.toggle()
    }
    @State var fireStarted = false
    func fireStart() {
        fireStarted = true
    }
    
    var body: some View {
        VStack(alignment: .leading) {
            Text("Click a tree:")
                .font(.custom("Futura", size: 30))
                .bold()
                .padding()
            Divider()
            Spacer()
            HStack{
                Spacer()
                VStack {
                    Button(action: { toggleOne() }) {
                        Image(systemName: onePressed ? "1.circle.fill" : "1.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleTwo() }) {
                        Image(systemName: twoPressed ? "2.circle.fill" : "2.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleThree() }) {
                        Image(systemName: threePressed ? "3.circle.fill" : "3.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleFour() }) {
                        Image(systemName: fourPressed ? "4.circle.fill" : "4.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleFive() }) {
                        Image(systemName: fivePressed ? "5.circle.fill" : "5.circle" )
                    }
                    .buttonStyle(Tree())
                }
                Spacer()
                VStack {
                    Button(action: { toggleSix() }) {
                        Image(systemName: sixPressed ? "6.circle.fill" : "6.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleSeven() }) {
                        Image(systemName: sevenPressed ? "7.circle.fill" : "7.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleEight() }) {
                        Image(systemName: eightPressed ? "8.circle.fill" : "8.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleNine() }) {
                        Image(systemName: ninePressed ? "9.circle.fill" : "9.circle" )
                    }
                    .buttonStyle(Tree())
                    Button(action: { toggleTen() }) {
                        Image(systemName: tenPressed ? "10.circle.fill" : "10.circle" )
                    }
                    .buttonStyle(Tree())
                }
                Spacer()
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
