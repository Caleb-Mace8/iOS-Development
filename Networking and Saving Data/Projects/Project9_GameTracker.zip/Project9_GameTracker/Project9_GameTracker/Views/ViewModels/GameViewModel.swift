//
//  GameViewViewModel.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import SwiftUI
import Observation
import SwiftData

@Observable
final class GameViewModel {
    private var context: ModelContext
    
    init(context: ModelContext) {
        self.context = context
    }
    
    func increase(player: Player) -> Void {
        player.score += 1
    }
    
    func decrease(player: Player) -> Void {
        if player.score > 0 {
            player.score -= 1
        }
    }
    
    func delete(players: [Player]) {
        for player in players {
            context.delete(player)
        }
    }
}
