    //
    //  GameAddViewModel.swift
    //  Project9_GameTracker
    //
    //  Created by Caleb Mace on 12/10/25.
    //
import SwiftUI
import Observation
import SwiftData

@Observable
final class GameAddViewModel {
    private var context: ModelContext
    var isEditing: Bool = false
    
    init(context: ModelContext, isEditing: Bool?) {
        self.context = context
        if let isEditing {
            self.isEditing = isEditing
        }
    }
    
    func saveGame(_ newGame: Game, games: [Game], dismiss: DismissAction) {
        if games.contains(newGame) {
            if let game = games.firstIndex(of: newGame) {
                let game = games[game]
                game.name = newGame.name
                game.sortingMethod = newGame.sortingMethod
                game.updatedAt = .now
            }
        } else {
            newGame.position = games.count
            context.insert(newGame)
        }
        dismiss()
    }
}
