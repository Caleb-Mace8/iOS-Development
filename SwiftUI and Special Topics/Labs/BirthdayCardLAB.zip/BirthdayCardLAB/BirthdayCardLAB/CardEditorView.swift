    //
    //  CardEditorView.swift
    //  BirthdayCardLAB
    //
    //  Created by Caleb Mace on 1/9/26.
    //
import SwiftUI
import PhotosUI

struct CardEditorView: View {
    @Environment(\.dismiss) var dismiss
    @State private var color: Color = Color.red
    @State private var image: PhotosPickerItem?
    @State var cardHolder: CardStore
    @State var card: Card = .init(recipient: "", sender: "", message: "")
    var body: some View {
        VStack {
            TextField("Who is the card to?", text: $card.recipient)
                .padding()
                .overlay {
                    RoundedRectangle(cornerRadius: 20)
                        .stroke()
                        .fill(.secondary)
                }
            TextField("Who is the card from?", text: $card.sender)
                .padding()
                .overlay {
                    RoundedRectangle(cornerRadius: 20)
                        .stroke()
                        .fill(.secondary)
                }
            TextField("What is the message?", text: $card.message)
                .padding()
                .overlay {
                    RoundedRectangle(cornerRadius: 20)
                        .stroke()
                        .fill(.secondary)
                }
            DatePicker("When do you want the card to arrive?", selection: $card.date, displayedComponents: .date)
            ColorPicker("What color do you want the card to be?", selection: $color)
                .padding()
            Circle()
                .fill(color)
                .frame(width: 50)
                .overlay {
                    Circle()
                        .stroke()
                        .foregroundStyle(Color.secondary)
                }
                .padding()
            PhotosPicker("Add an Image to your card", selection: $image)
                .onChange(of: image) {
                    loadImageData(image)
                }
            Button {
                card.color = color
                cardHolder.cards.append(card)
                dismiss()
            } label: {
                Text("Save")
                    .font(.largeTitle)
                    .frame(width: 300)
            }
            .buttonStyle(.glassProminent)
            .padding()
        }
        .padding()
    }
    
    func loadImageData(_ newValue: PhotosPickerItem?) {
        Task {
            if let newValue {
                if let data = try? await newValue.loadTransferable(type: Data.self) {
                    card.image = data
                }
            }
        }
    }
}
