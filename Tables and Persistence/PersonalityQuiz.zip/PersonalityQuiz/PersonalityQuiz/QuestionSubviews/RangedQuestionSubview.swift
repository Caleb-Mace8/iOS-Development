//
//  RangedQuestionSubview.swift
//  PersonalityQuiz
//
//  Created by Caleb Mace on 11/9/25.
//
import SwiftUI

struct RangedQuestionSubview: View {
    @State private var sliderValue: Double = 1.5
    var question: Question
    @Environment(QuizManager.self) var quizManager
    
    init (question: Question) {
        self.question = question
    }
    
    var body: some View {
        VStack {
            Text("Current Question: \(quizManager.questionList.firstIndex(of: question)! + 1)")
                .titleTextStyle()
                .padding()
            Spacer()
            Text(question.text)
                .titleTextStyle()
                .padding()
                .background() {
                    Rectangle()
                        .foregroundColor(.blue)
                        .frame(width: 375)
                }
                .padding()
            HStack {
                Text(question.answers[0].text)
                    .padding()
                    .subFontStyle()
                Text(question.answers[1].text)
                    .padding()
                    .subFontStyle()
                Text(question.answers[2].text)
                    .padding()
                    .subFontStyle()
                Text(question.answers[3].text)
                    .padding()
                    .subFontStyle()
            }
            Slider(value: $sliderValue, in: 0...3, step: 1)
                .padding()
                .onChange(of: sliderValue) { _, newValue in
                    let index = Int(newValue.rounded())
                    guard question.answers.indices.contains(index) else { return }
                    quizManager.selectAnswer(question.answers[index])
                }
            Spacer()
        }
    }
}
