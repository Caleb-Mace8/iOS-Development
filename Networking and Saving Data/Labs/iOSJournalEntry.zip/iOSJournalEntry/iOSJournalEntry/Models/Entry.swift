//
//  Entry.swift
//  iOSJournalEntry
//
//  Created by Caleb Mace on 12/3/25.
//
import Foundation
import SwiftData

@Model
class Entry: Identifiable {
    var id: UUID = UUID()
    var title: String
    var body: String
    var date: Date
    var journal: Journal?
    
    
    init(title: String, body: String, journal: Journal?, date: Date = .now) {
        self.title = title
        self.body = body
        self.date = date
        self.journal = journal
    }
}
