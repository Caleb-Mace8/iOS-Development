//
//  APIController.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//
import Foundation

protocol APIController {
    associatedtype result
    
    func fetchData() async throws -> result
}
