//
//  Emoji.swift
//  EmojiDictionary
//
//  Created by Jane Madsen on 10/30/25.
//

import Foundation

struct Emoji: Codable, Identifiable, Equatable {
    var id: UUID = UUID()
    var symbol: String
    var name: String
    var description: String
    var usage: String
}

func saveToFile(emojis: [Emoji]) {
    let archiveURl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("emojis").appendingPathExtension(".plist")
    let propertyListEncoder = PropertyListEncoder()
    let encodedEmojis = try? propertyListEncoder.encode(emojis)
    try? encodedEmojis?.write(to: archiveURl)
}

func loadFromFile() -> [Emoji]? {
    let archiveURl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!.appendingPathComponent("emojis").appendingPathExtension(".plist")
    let propertListDecoder = PropertyListDecoder()
    if let decodedEmojis = try? Data(contentsOf: archiveURl), let decodedEmojis = try? propertListDecoder.decode(Array<Emoji>.self, from: decodedEmojis) {
        return decodedEmojis
    }
    return nil
}

let sampleEmoji = [
    Emoji(symbol: "😀", name: "Grinning Face", description: "A typical smiley face.", usage: "happiness"),
    Emoji(symbol: "😂", name: "Face with Tears of Joy", description: "Laughing so hard that tears come out.", usage: "laughter"),
    Emoji(symbol: "🥰", name: "Smiling Face with Hearts", description: "A warm, affectionate smile surrounded by hearts.", usage: "affection"),
    Emoji(symbol: "😎", name: "Smiling Face with Sunglasses", description: "Cool and confident.", usage: "cool"),
    Emoji(symbol: "🤔", name: "Thinking Face", description: "A face pondering a question.", usage: "thinking"),
    Emoji(symbol: "😭", name: "Loudly Crying Face", description: "Sobbing with streams of tears.", usage: "sadness"),
    Emoji(symbol: "😍", name: "Smiling Face with Heart-Eyes", description: "In love or adoration.", usage: "love"),
    Emoji(symbol: "🤯", name: "Exploding Head", description: "Mind blown.", usage: "shock"),
    Emoji(symbol: "🥳", name: "Partying Face", description: "Celebrating something exciting.", usage: "party"),
    Emoji(symbol: "🙌", name: "Raising Hands", description: "Hands raised in celebration.", usage: "celebration"),
    Emoji(symbol: "👍", name: "Thumbs Up", description: "Approval or agreement.", usage: "approve"),
    Emoji(symbol: "🔥", name: "Fire", description: "Something is awesome or on a hot streak.", usage: "lit"),
    Emoji(symbol: "✨", name: "Sparkles", description: "Shiny, new, or special.", usage: "sparkle"),
    Emoji(symbol: "🌟", name: "Glowing Star", description: "A standout moment.", usage: "highlight"),
    Emoji(symbol: "🌈", name: "Rainbow", description: "Colorful and cheerful.", usage: "pride"),
    Emoji(symbol: "🍎", name: "Red Apple", description: "A fresh red apple.", usage: "food"),
    Emoji(symbol: "🍕", name: "Pizza", description: "A slice of cheesy goodness.", usage: "food"),
    Emoji(symbol: "🍔", name: "Hamburger", description: "Classic burger.", usage: "food"),
    Emoji(symbol: "🍣", name: "Sushi", description: "Delicious Japanese cuisine.", usage: "food"),
    Emoji(symbol: "☕️", name: "Hot Beverage", description: "Coffee or tea break.", usage: "coffee"),
    Emoji(symbol: "🧋", name: "Bubble Tea", description: "Boba time.", usage: "drink"),
    Emoji(symbol: "⚽️", name: "Soccer Ball", description: "Football/soccer.", usage: "sports"),
    Emoji(symbol: "🏀", name: "Basketball", description: "Hoops time.", usage: "sports"),
    Emoji(symbol: "🎸", name: "Guitar", description: "Rock on.", usage: "music"),
    Emoji(symbol: "🎧", name: "Headphone", description: "Listening to music or podcasts.", usage: "audio"),
    Emoji(symbol: "🎉", name: "Party Popper", description: "Celebrate and confetti.", usage: "celebration"),
    Emoji(symbol: "📚", name: "Books", description: "Study or reading time.", usage: "study"),
    Emoji(symbol: "💡", name: "Light Bulb", description: "A bright idea.", usage: "idea"),
    Emoji(symbol: "🧠", name: "Brain", description: "Thinking, intelligence.", usage: "knowledge"),
    Emoji(symbol: "💻", name: "Laptop", description: "Coding or working.", usage: "work"),
    Emoji(symbol: "📱", name: "Mobile Phone", description: "Calling or texting.", usage: "phone"),
    Emoji(symbol: "🕹️", name: "Joystick", description: "Gaming time.", usage: "gaming"),
    Emoji(symbol: "🚗", name: "Automobile", description: "Driving or travel.", usage: "travel"),
    Emoji(symbol: "✈️", name: "Airplane", description: "Flying somewhere.", usage: "travel"),
    Emoji(symbol: "🏝️", name: "Desert Island", description: "Vacation vibes.", usage: "vacation"),
    Emoji(symbol: "🏔️", name: "Snow-Capped Mountain", description: "Outdoors and hiking.", usage: "outdoors"),
    Emoji(symbol: "🌧️", name: "Cloud with Rain", description: "Rainy weather.", usage: "weather"),
    Emoji(symbol: "🌞", name: "Sun with Face", description: "Sunny and warm.", usage: "weather"),
    Emoji(symbol: "🌙", name: "Crescent Moon", description: "Nighttime.", usage: "night"),
    Emoji(symbol: "⭐️", name: "Star", description: "A simple star.", usage: "star"),
    Emoji(symbol: "🐶", name: "Dog Face", description: "Man's best friend.", usage: "dog"),
    Emoji(symbol: "🐱", name: "Cat Face", description: "Cute kitty.", usage: "cat"),
    Emoji(symbol: "🦊", name: "Fox", description: "Sly and clever.", usage: "fox"),
    Emoji(symbol: "🐼", name: "Panda", description: "Bamboo lover.", usage: "panda"),
    Emoji(symbol: "🦄", name: "Unicorn", description: "Magical creature.", usage: "magic"),
    Emoji(symbol: "🌸", name: "Cherry Blossom", description: "Springtime flower.", usage: "spring"),
    Emoji(symbol: "🍁", name: "Maple Leaf", description: "Autumn vibes.", usage: "fall"),
    Emoji(symbol: "❄️", name: "Snowflake", description: "Winter chill.", usage: "winter"),
    Emoji(symbol: "🌊", name: "Water Wave", description: "Ocean wave.", usage: "water"),
    Emoji(symbol: "⚡️", name: "High Voltage", description: "Energy or electricity.", usage: "energy"),
    Emoji(symbol: "❤️", name: "Red Heart", description: "Classic love heart.", usage: "love"),
    Emoji(symbol: "💯", name: "Hundred Points", description: "Keep it 100.", usage: "success")
]
