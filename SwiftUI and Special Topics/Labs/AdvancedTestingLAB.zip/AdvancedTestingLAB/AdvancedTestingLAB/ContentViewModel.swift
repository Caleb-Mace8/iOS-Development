//
//  ContentViewModel.swift
//  AdvancedTestingLAB
//
//  Created by Caleb Mace on 1/28/26.
//
import Observation

@Observable
class ContentViewModel {
    var email: String = ""
    var password: String = ""
    var isLoggedIn: Bool = false
    
    func login() -> Bool {
        var hasLowercase: Bool = false
        var hasUppercase: Bool = false
        var hasNumber: Bool = false
        var hasSpecialCharacter: Bool = false
        guard password.count >= 8 && password.count <= 30 else { return false }
        for letter in password {
            if letter.isLowercase {
                print("found lowercase")
                hasLowercase = true
            }
            if letter.isUppercase {
                print("found uppercase")
                hasUppercase = true
            }
            if letter.isNumber {
                print("found number")
                hasNumber = true
            }
            if letter.isPunctuation || letter.isCurrencySymbol || letter.isMathSymbol || letter.isSymbol {
                print("found symbol")
                hasSpecialCharacter = true
            }
        }
        if hasLowercase == true && hasUppercase == true && hasNumber == true && hasSpecialCharacter == true {
            return true
        } else {
            return false
        }
    }
}


struct ContentViewTestable {
    var email: String = ""
    var password: String = ""
    
    func login() -> Bool {
        var hasLowercase: Bool = false
        var hasUppercase: Bool = false
        var hasNumber: Bool = false
        var hasSpecialCharacter: Bool = false
        guard password.count >= 8 && password.count <= 30 else { return false }
        for letter in password {
            if letter.isLowercase {
                print("found lowercase")
                hasLowercase = true
            }
            if letter.isUppercase {
                print("found uppercase")
                hasUppercase = true
            }
            if letter.isNumber {
                print("found number")
                hasNumber = true
            }
            if letter.isPunctuation || letter.isCurrencySymbol || letter.isMathSymbol || letter.isSymbol {
                print("found symbol")
                hasSpecialCharacter = true
            }
        }
        if hasLowercase == true && hasUppercase == true && hasNumber == true && hasSpecialCharacter == true {
            return true
        } else {
            return false
        }
    }
}
