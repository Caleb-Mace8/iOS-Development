//
//  ContentView.swift
//  AnimationLAB
//
//  Created by Caleb Mace on 12/8/25.
//

import SwiftUI

struct ContentView: View {
    @State private var start = false
    @State private var countdownNum: Int = 3
    @State private var opacity: Double = 0
    @State private var scale: CGFloat = 1.4
    var imageViewID: String = "ImageView"
    @Namespace private var animation
    
    var imageCount: Int {
        switch countdownNum {
        case 3:
            return 3
        case 2:
            return 2
        case 1:
            return 1
        default:
            return 0
        }
    }
    
    var body: some View {
        ZStack {
            LinearGradient(
                colors: [.purple, .indigo, .blue],
                startPoint: .topLeading,
                endPoint: .bottomTrailing
            )
            .ignoresSafeArea()
            .opacity(0.6)
            
            VStack {
                if !start {
                    Text("The game!")
                        .font(.largeTitle.bold())
                    
                    Button {
                        withAnimation(.default.speed(0.25)) {
                            start.toggle()
                        }
                        Task { await runCountdown() }
                    } label: {
                        Text("Start Game!")
                            .bold()
                            .frame(width: 200, height: 25)
                    }
                    .padding()
                    .buttonStyle(.glass)
                    
                } else {
                    Group {
                        if countdownNum > 0 {
                            ZStack {
                                Text("\(countdownNum)")
                                    .font(.system(size: 80, weight: .heavy, design: .rounded))
                                    .foregroundColor(.white)
                                    .opacity(opacity)
                                    .scaleEffect(scale)
                                    .animation(.easeInOut(duration: 0.4), value: opacity)
                                    .animation(.spring(response: 0.5, dampingFraction: 0.7), value: scale)
                                if countdownNum == 1 {
                                    Image(systemName: "gauge.with.dots.needle.bottom.100percent")
                                        .resizable()
                                        .matchedGeometryEffect(id: imageViewID, in: animation)
                                        .frame(width: 150, height: 150)
                                        .offset(x: 100, y: 150)
                                        .foregroundStyle(.white)
                                } else if countdownNum == 2 {
                                    Image(systemName: "gauge.with.dots.needle.bottom.50percent")
                                        .resizable()
                                        .matchedGeometryEffect(id: imageViewID, in: animation)
                                        .frame(width: 100, height: 100)
                                        .offset(x: -100, y: 200)
                                        .foregroundStyle(.white)
                                } else if countdownNum == 3 {
                                    Image(systemName: "gauge.with.dots.needle.bottom.0percent")
                                        .resizable()
                                        .matchedGeometryEffect(id: imageViewID, in: animation)
                                        .frame(width: 50, height: 50)
                                        .offset(x: 100, y: 300)
                                        .foregroundStyle(.white)
                                }
                            }
                        } else {
                            Text("Go!")
                                .onTapGesture() {
                                    start = false
                                }
                                .font(.system(size: 80, weight: .heavy, design: .rounded))
                                .foregroundColor(.white)
                                .opacity(opacity)
                                .scaleEffect(scale)
                                .animation(.easeInOut(duration: 0.4), value: opacity)
                                .animation(.spring(response: 0.5, dampingFraction: 0.7), value: scale)
                                .padding()
                        }
                    }
                }
            }
        }
    }
    
    private func runCountdown() async {
        for current in stride(from: 3, through: 0, by: -1) {
            await MainActor.run {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                    countdownNum = current
                }
                opacity = 0.0
                scale = 0.2
            }
            await MainActor.run {
                withAnimation(.easeInOut(duration: 0.25)) {
                    opacity = 1.0
                }
            }
            try? await Task.sleep(nanoseconds: 150_000_000)
            await MainActor.run {
                withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                    scale = CGFloat(1 + (0.7 * Double(abs(current - 3))))
                }
            }
            try? await Task.sleep(nanoseconds: 700_000_000)
        }
    }
}

#Preview {
    ContentView()
}
