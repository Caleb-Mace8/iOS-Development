//
//  DogEditView.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//
import SwiftUI

struct DogEditView: View {
    @Binding var dog: Dog
    
    var body: some View {
        VStack {
            TextField(dog.name, text: $dog.name)
                .textFieldStyle(.roundedBorder)
                .padding()
            AsyncImage(url: dog.image) { image in
                image.resizable()
            } placeholder: {
                ProgressView()
            }
            .frame(width: 375, height: 375)
            .padding()
        }
        .padding()
    }
}
