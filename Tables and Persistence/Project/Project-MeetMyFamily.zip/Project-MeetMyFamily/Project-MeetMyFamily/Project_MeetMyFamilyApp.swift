//
//  Project_MeetMyFamilyApp.swift
//  Project-MeetMyFamily
//
//  Created by Caleb Mace on 10/10/25.
//

import SwiftUI

@main
struct Project_MeetMyFamilyApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
