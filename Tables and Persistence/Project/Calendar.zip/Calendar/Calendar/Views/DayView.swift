//
//  DayView.swift
//  Calendar
//
//  Created by Caleb Mace on 11/17/25.
//
import SwiftUI

struct DayView: View {
    let day: Day
    let dayInfo: [String: String]
    let viewModel = DayViewModel()
    
    init(day: Day) {
        self.day = day
        dayInfo = [
            "Objective": day.objective,
            "Reading Due": day.readingDue,
            "Assignments Due": day.assignmentsDue?.title ?? "none",
            "New Assignments": day.newAssignments?.title ?? "none",
            "Code Challenge": day.codeChallenge,
            "Word of the Day": day.wordOfTheDay
        ]
    }
    
    var body: some View {
        @Bindable var model = viewModel
        NavigationStack {
            Text(day.lesson.title)
                .font(.custom("system", size: 40))
                .padding()
            HStack{
                Text("\(day.id):")
                    .font(.custom("system", size: 25))
                    .bold()
                Text(day.date)
                    .font(.custom("system", size: 25))
                    .italic()
            }
            .padding()
            List {
                ForEach(dayInfo.keys.sorted(), id: \.self) { key in
                    viewModel.forEachDisplay(key: key, dayInfo: dayInfo, day: day)
                }
            }
            NavigationLink(destination: SubmitFeedbackView()) {
                Text("Submit Feedback")
            }
            .buttonStyle(.borderedProminent)
            .padding()
        }
        .sheet(isPresented: $model.isShowingSheet, onDismiss: { viewModel.selectedAssignment = Assignment(title: "", description: "") }) {
            if viewModel.selectedAssignment != Assignment(title: "", description: "") {
                AssignmentOutline(assignment: viewModel.selectedAssignment)
            }
        }
        .onChange(of: viewModel.selectedAssignment) {
            if viewModel.selectedAssignment != Assignment(title: "", description: "") {
                viewModel.isShowingSheet.toggle()
            }
        }
    }
}


#Preview {
    DayView(day: DayFetchManager(dayProvider: MockDataProvider()).getDay())
}

