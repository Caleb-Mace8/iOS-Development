//
//  PlayerAddEditView.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import SwiftUI
import SwiftData

struct PlayerAddEditView: View {
    @Environment(MainRouter.self) var router
    @Environment(\.modelContext) var context
    @State var viewModel: PlayerAddEditViewModel?
    @Environment(\.dismiss) var dismiss
    @State var game: Game
    @State var player: Player
    var isEditing: Bool = false
    
    init(player: Player?, game: Game) {
        if let player {
            self.player = player
            isEditing = true
        } else {
            self.player = .init(name: "New Player", game: game)
        }
        self.game = game
    }
    
    var body: some View {
        VStack {
            if let viewModel {
                VStack {
                    Text("Player Name:")
                        .font(Font.headline.bold())
                    TextField("Type Player Name", text: $player.name, prompt: Text("Enter player name..."))
                        .padding()
                        .background {
                            Rectangle()
                                .foregroundStyle(.thinMaterial)
                                .overlay {
                                    Rectangle()
                                        .stroke()
                                        .foregroundStyle(.secondary.opacity(0.5))
                                }
                        }
                        .padding()
                    HStack {
                        Button {
                            viewModel.save(newPlayer: player, players: game.players, dismiss: dismiss)
                        } label: {
                            Text("Save")
                                .frame(width: 100, height: 20)
                        }
                        .buttonStyle(.glassProminent)
                        Button {
                            dismiss()
                        } label: {
                            Text("Dismiss")
                                .frame(width: 100, height: 20)
                        }
                        .buttonStyle(.glass)
                    }
                }
            } else {
               ProgressView()
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = .init(context: context)
            }
        }
        .navigationBarBackButtonHidden()
        .navigationTitle(isEditing ? "Edit Player" : "Add Player")
    }
}
