//
//  Untitled.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import Observation

@Observable
class RootViewViewModel {
    var router = MainRouter()
}
