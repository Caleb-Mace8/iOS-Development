//
//  QuestionFlowView.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/13/25.
//

import SwiftUI

struct QuestionFlowView: View {
    @Environment(QuizManager.self) var quizManager
    
    @State private var singleSelection: Answer?
    @State private var multipleSelection: [Answer?] = []
    @State private var rangedSelection: Answer?
    var question: Question
    
    init (question: Question) {
        self.question = question
    }
    
    var body: some View {
        NavigationStack {
            VStack {
                switch question.type {
                case .single:
                    SingleQuestionSubview(quizManager: quizManager, question: question, viewModel: SingleQuestionViewModel(quizManager: quizManager, question: question))
                case .multiple:
                    MultipleQuestionSubview(question: question)
                case .ranged:
                    RangedQuestionSubview(question: question)
                }
            }
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    NavigationLink("Next") {
                        if let nextQuestion = quizManager.nextQuestion(after: question) {
                            QuestionFlowView(question: nextQuestion)
                        } else {
                            ResultsView(result: quizManager.calculateResult())
                        }
                    }
                    .fontStyle()
                    .buttonStyle(.borderedProminent)
                }
            }
//            .navigationBarBackButtonHidden()
        }
    }
}

#Preview {
    TitleView()
}
