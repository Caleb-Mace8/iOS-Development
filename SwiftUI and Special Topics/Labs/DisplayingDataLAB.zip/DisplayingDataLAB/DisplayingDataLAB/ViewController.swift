//
//  ViewController.swift
//  DisplayingDataLAB
//
//  Created by Caleb Mace on 1/20/26.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

