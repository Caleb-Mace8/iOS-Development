//
//  Journal.swift
//  iOSJournalEntry
//
//  Created by Caleb Mace on 12/2/25.
//
import Foundation
import SwiftData

@Model
class Journal {
    var title: String
    var date: Date
    @Relationship(deleteRule: .cascade, inverse: \Entry.journal) var entries: [Entry]
    
    init(title: String, date: Date = .now, entries: [Entry] = []) {
        self.title = title
        self.date = date
        self.entries = entries
    }
}

