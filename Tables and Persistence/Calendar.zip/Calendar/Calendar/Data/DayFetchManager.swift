//
//  DayFetchManager.swift
//  Calendar
//
//  Created by Caleb Mace on 11/19/25.
//
import SwiftUI
import Observation

// Creates an object for managing fetching days based on a inputted DataProvider

@Observable
class DayFetchManager {
    var days: [Day] = []
    var dayProvider: DataProvider
    
    init(dayProvider: DataProvider) {
        self.dayProvider = dayProvider
    }
    
    func getDay() -> Day {
        dayProvider.getDays().first!
    }
    
    func getDays() -> [Day] {
        let result = dayProvider.getDays()
        days = result
        return result
    }
}
