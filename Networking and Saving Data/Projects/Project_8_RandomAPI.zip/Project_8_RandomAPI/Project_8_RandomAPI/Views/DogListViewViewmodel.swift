//
//  DogListViewViewmodel.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//
import SwiftUI
import Observation

@Observable
class DogListViewViewModel {
    var dogAPIFetcher: DogAPIController
    var currentDog: Dog = Dog(name: "", status: "")
    var dogs: [Dog] = []
    
    init(dogAPIFetcher: DogAPIController) {
        self.dogAPIFetcher = dogAPIFetcher
    }
    
    func fetchDogs() async throws -> Dog {
        try await dogAPIFetcher.fetchData()
    }
}
