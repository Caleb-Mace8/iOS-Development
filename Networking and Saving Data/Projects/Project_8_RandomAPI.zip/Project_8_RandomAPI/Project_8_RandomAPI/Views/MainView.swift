//
//  MainView.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            Tab("Dogs", systemImage: "dog") {
                DogListView()
            }
            Tab("US rep.", systemImage: "person.2.fill") {
                RepresentativesView()
            }
        }
    }
}

#Preview {
    MainView()
}
