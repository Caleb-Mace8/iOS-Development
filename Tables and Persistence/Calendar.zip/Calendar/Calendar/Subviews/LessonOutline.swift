//
//  LessonOutline.swift
//  Calendar
//
//  Created by Caleb Mace on 11/19/25.
//

import SwiftUI

struct LessonOutline: View {
    @State private var lesson: Lesson
    
    init(lesson: Lesson) {
        self.lesson = lesson
    }
    
    var body: some View {
        VStack {
            Text(lesson.title)
                .font(.largeTitle)
                .padding()
            Text(lesson.description)
                .padding()
        }
    }
}
