//
//  FontStyles.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/13/25.
//
import SwiftUI

struct TitleTextStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("AvenirNext-Bold", size: 25))
            .foregroundStyle(.primary)
    }
}

struct FontStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("AvenirNext-Bold", size: 15))
            .foregroundStyle(.primary)
    }
}

struct SubFontStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("AvenirNext-Bold", size: 13))
            .foregroundStyle(.primary)
            .lineSpacing(2)
            .tracking(0.5)
    }
}


extension View {
    func titleTextStyle() -> some View {
        self.modifier(TitleTextStyle())
    }
    func fontStyle() -> some View {
        self.modifier(FontStyle())
    }
    func subFontStyle() -> some View {
        self.modifier(SubFontStyle())
    }
}
