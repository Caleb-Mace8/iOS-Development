//
//  FakeStubMockLABApp.swift
//  FakeStubMockLAB
//
//  Created by Caleb Mace on 1/26/26.
//

import SwiftUI

@main
struct FakeStubMockLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
