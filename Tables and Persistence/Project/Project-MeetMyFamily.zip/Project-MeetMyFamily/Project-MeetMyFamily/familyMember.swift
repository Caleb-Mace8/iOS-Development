//
//  familyMember.swift
//  Project-MeetMyFamily
//
//  Created by Caleb Mace on 10/10/25.
//
import SwiftUI

struct FamilyMember: Identifiable {
    var id: UUID = UUID()
    var name: String
    var age: Int
    var relationship: String
    var image: String
    var discription: String
}
