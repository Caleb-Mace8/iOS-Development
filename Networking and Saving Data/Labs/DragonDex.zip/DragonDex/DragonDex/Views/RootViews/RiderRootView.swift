//
//  RiderRootView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI

struct RiderRootView: View {
    @State var riderRouter: RiderRouter = RiderRouter()
    @Environment(MainRouter.self) var mainRouter
    
    var body: some View {
        NavigationStack(path: $riderRouter.navigationPath) {
            RiderListView(riders: riders)
                .navigationDestination(for: RiderRouter.RiderRoute.self) { route in
                    riderRouter.view(for: route)
                }
        }
        .environment(riderRouter)
    }
}

