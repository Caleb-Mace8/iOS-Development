//
//  Project9_GameTrackerApp.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//

import SwiftUI
import SwiftData

@main
struct Project9_GameTrackerApp: App {
    var body: some Scene {
        WindowGroup {
            RootView()
        }
        .modelContainer(for: Game.self)
    }
}
