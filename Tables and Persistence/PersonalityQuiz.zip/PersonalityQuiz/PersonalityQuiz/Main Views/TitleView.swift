//
//  TitleView.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/13/25.
//

import SwiftUI

struct TitleView: View {
    var quizManager = QuizManager()
    
    var body: some View {
        NavigationStack {
            Spacer()
            Text("What does your future ACTUALLY look like?")
                .titleTextStyle()
            Spacer()
            Image(.clockTimeTitle)
                .resizable()
                .frame(width: 350, height: 200)
                .padding()
                .shadow(radius: 10)
            Spacer()
            NavigationLink {
                QuestionFlowView(question: quizManager.questionList[0])
            } label: {
                Text("Start")
                    .titleTextStyle()
                    .frame(maxWidth: .infinity)
            }
            .padding(.vertical, 14)
            .font(.custom("Futura", size: 14))
            .foregroundColor(.white)
            .background (
                Color.accentColor
                    .clipShape(.capsule)
            )
            .padding()
            Spacer()
        }
        .environment(quizManager)
        .padding()
    }
}

#Preview {
    TitleView()
}
