//
//  Dragon.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//

import SwiftUI

enum DragonType: Hashable {
    case fire
    case ice
    case storm
    case earth
    case shadow
    case light
    case water
    case wind
    case arcane
}

extension DragonType {
    var displayName: String {
        switch self {
        case .fire: return "Fire"
        case .ice: return "Ice"
        case .storm: return "Storm"
        case .earth: return "Earth"
        case .shadow: return "Shadow"
        case .light: return "Light"
        case .water: return "Water"
        case .wind: return "Wind"
        case .arcane: return "Arcane"
        }
    }
}

struct Dragon: Hashable {
    var name: String
    var species: DragonType
    var lore: String
    var powerRating: Int // 1-5 for power rating
    var powers: [String]
    var color: Color
    var image: String
}

let dragons: [Dragon] = [
    Dragon(
        name: "Pyrax",
        species: .fire,
        lore: "A volcanic dragon said to roost in magma chambers, igniting the skies during eclipses.",
        powerRating: 5,
        powers: ["Flame Breath", "Heat Aura", "Cinder Storm"],
        color: .orange,
        image: "flame.fill"
    ),
    Dragon(
        name: "Glacielle",
        species: .ice,
        lore: "An ancient wyrm that freezes fjords with a single whisper of winter.",
        powerRating: 4,
        powers: ["Frost Nova", "Ice Shards", "Permafrost Shield"],
        color: .cyan,
        image: "snowflake"
    ),
    Dragon(
        name: "Tempestrix",
        species: .storm,
        lore: "Rider of tempests, drumming thunder with each beat of its wings.",
        powerRating: 5,
        powers: ["Lightning Arc", "Gale Force", "Storm Surge"],
        color: .indigo,
        image: "cloud.bolt.rain.fill"
    ),
    Dragon(
        name: "Terragon",
        species: .earth,
        lore: "A mountain-born guardian whose scales are as tough as bedrock.",
        powerRating: 4,
        powers: ["Stone Skin", "Quake", "Root Snare"],
        color: .green,
        image: "mountain.2.fill"
    ),
    Dragon(
        name: "Umbrath",
        species: .shadow,
        lore: "A silhouette in moonless nights, seen only as a ripple in the dark.",
        powerRating: 3,
        powers: ["Shadowstep", "Night Veil", "Dread Gaze"],
        color: .purple,
        image: "moon.zzz.fill"
    ),
    Dragon(
        name: "Luminara",
        species: .light,
        lore: "A radiant serpent whose halo guides lost travelers home.",
        powerRating: 4,
        powers: ["Sunlance", "Radiant Ward", "Beacon"],
        color: .yellow,
        image: "sun.max.fill"
    ),
    Dragon(
        name: "Aqualith",
        species: .water,
        lore: "Keeper of coral palaces, weaving tides like threads.",
        powerRating: 3,
        powers: ["Tidal Wave", "Mist Cloak", "Abyssal Pull"],
        color: .blue,
        image: "drop.fill"
    ),
    Dragon(
        name: "Zephyra",
        species: .wind,
        lore: "Fleet-winged spirit that carves canyons with invisible blades.",
        powerRating: 3,
        powers: ["Air Slash", "Tailwind", "Vacuum Sphere"],
        color: .teal,
        image: "wind"
    ),
    Dragon(
        name: "Arcanis",
        species: .arcane,
        lore: "A scholar-drake whose runed scales hum with ancient sigils.",
        powerRating: 5,
        powers: ["Mana Burst", "Spellweave", "Ward of Ages"],
        color: .mint,
        image: "sparkles"
    )
]
