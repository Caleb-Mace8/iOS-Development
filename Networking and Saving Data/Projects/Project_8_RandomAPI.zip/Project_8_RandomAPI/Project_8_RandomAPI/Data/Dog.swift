//
//  dog.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//
import Foundation

struct Dog: Codable, Identifiable, Equatable {
    let id = UUID()
    var name: String = ""
    var image: URL? = nil
    var status: String
    
    enum CodingKeys: String, CodingKey {
        case image = "message"
        case status
    }
}
