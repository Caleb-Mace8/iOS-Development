//
//  JournalView.swift
//  iOSJournalEntry
//
//  Created by Caleb Mace on 12/3/25.
//

import SwiftUI
import SwiftData

struct JournalView: View {
    @Environment(\.modelContext) var context
    @State var journal: Journal
    @State private var isPresenting: Bool = false
    @State var entries: [Entry?]
    
    init(journal: Journal) {
        self.journal = journal
        entries = journal.entries
    }
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.secondarySystemBackground)
                    .ignoresSafeArea()
                VStack {
                    if let entries = entries as? [Entry] {
                        List {
                            ForEach(entries) { entry in
                                NavigationLink() {
                                    EntryDetailView(entry: entry, save: saveEntry)
                                } label: {
                                    HStack(spacing: 12) {
                                        Image(systemName: "book.pages")
                                            .resizable()
                                            .frame(width: 35, height: 40)
                                            .padding(.vertical, 8)
                                        VStack(alignment: .leading, spacing: 4) {
                                            Text(entry.title)
                                                .font(.title3)
                                                .bold()
                                            Text(entry.date, style: .date)
                                                .font(.subheadline)
                                                .italic()
                                                .foregroundStyle(.secondary)
                                        }
                                        Spacer()
                                    }
                                    .padding(.horizontal)
                                    .frame(minWidth: 275)
                                    .background(
                                        RoundedRectangle(cornerRadius: 8)
                                            .fill(Color(.secondarySystemBackground))
                                    )
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 8)
                                            .stroke(.secondary)
                                    )
                                }
                            }
                            .onDelete(perform: deleteEntry)
                        }
                        .listStyle(.inset)
                    } else {
                        VStack {
                            Text("You have no entries.")
                                .font(.title)
                                .foregroundColor(.secondary)
                                .bold()
                            Button {
                                saveEntry(Entry(title: "New Entry", body: "", journal: journal))
                            } label: {
                                Image(systemName: "plus.circle.fill")
                                Text("Add a entry")
                            }
                        }
                    }
                }
            }
            .toolbar {
                Button {
                    saveEntry(Entry(title: "New Entry", body: "", journal: journal))
                } label: {
                    Image(systemName: "plus")
                }
            }
            .navigationTitle(journal.title)
        }
    }
}

extension JournalView {
    private func deleteEntry(at offsets: IndexSet) {
        for index in offsets {
            if let entries = entries as? [Entry] {
                self.entries.remove(at: index)
                context.delete(entries[index])
            }
        }
    }
    
    private func saveEntry(_ newEntry: Entry) {
        if entries.contains(newEntry) {
            if let entries = entries as? [Entry] {
                guard let index = entries.firstIndex(of: newEntry) else { return }
                let entry = entries[index]
                entry.title = newEntry.title
                isPresenting = false
            }
        } else {
            context.insert(newEntry)
            entries.append(newEntry)
            isPresenting = false
        }
    }
}
