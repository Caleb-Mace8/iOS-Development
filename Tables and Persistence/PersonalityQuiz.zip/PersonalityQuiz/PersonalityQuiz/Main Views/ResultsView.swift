//
//  ResultsView.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/13/25.
//

import SwiftUI

struct ResultsView: View {
    var result: Result
    @Environment(QuizManager.self) var quizManager
    
    init (result: Result) {
        self.result = result
    }
    
    var body: some View {
        VStack(alignment: .center){
            HStack {
                Text("Your Result:")
                    .titleTextStyle()
                Spacer()
            }
            .padding()
            Spacer()
            Text(result.title)
                .titleTextStyle()
                .background() {
                    Rectangle()
                        .foregroundColor(.blue)
                        .frame(width:375)
                }
                .padding()
            Spacer()
            Text(result.description)
                .fontStyle()
            Spacer()
            Image(result.image)
                .resizable()
                .frame(width: 300, height: 300)
            Spacer(minLength: 100)
        }
        .toolbar {
        }
        .navigationBarBackButtonHidden()
    }
}

//#Preview {
//    ResultsView()
//}
