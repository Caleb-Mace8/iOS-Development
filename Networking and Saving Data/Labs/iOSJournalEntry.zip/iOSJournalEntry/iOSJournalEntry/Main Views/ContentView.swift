//
//  ContentView.swift
//  iOSJournalEntry
//
//  Created by Caleb Mace on 12/2/25.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    @Query(sort: \Journal.date, order: .reverse) private var journals: [Journal]
    @Environment(\.modelContext) private var context
    @State private var isPresenting: Bool = false
    @State private var journalBeingEdited: Journal? = nil
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(.secondarySystemBackground)
                    .ignoresSafeArea()
                if !journals.isEmpty {
                    List {
                        ForEach(journals) { journal in
                            JournalCard(journal: journal) {
                                journalBeingEdited = journal
                                isPresenting = true
                            }
                        }
                        .onDelete(perform: deleteEntry) 
                    }
                    .listStyle(.inset)
                } else {
                    VStack {
                        Text("You have no journals.")
                            .font(.title)
                            .foregroundColor(.secondary)
                            .bold()
                        Button {
                            let new = Journal(title: "New Journal")
                            context.insert(new)
                            journalBeingEdited = new
                            isPresenting = true
                        } label: {
                            Image(systemName: "plus.circle.fill")
                            Text("Add a journal")
                        }
                    }
                }
            }
            .toolbar {
                Button() {
                    let new = Journal(title: "New Journal")
                    context.insert(new)
                    journalBeingEdited = new
                    isPresenting = true
                } label: {
                    Image(systemName: "plus")
                    
                }
            }
            .navigationTitle(Text("Journals"))
            .sheet(item: $journalBeingEdited) { journal in
                JournalDetailView(journal: journal, save: saveEntry)
            }
        }
    }
}

// View for the cards displaying the journal
struct JournalCard: View {
    let journal: Journal
    var onEdit: (() -> Void)? = nil
    
    var body: some View {
        NavigationLink {
            JournalView(journal: journal)
        } label: {
            HStack(spacing: 12) {
                Image(systemName: "book.closed")
                    .resizable()
                    .frame(width: 35, height: 40)
                    .padding(.vertical, 8)
                VStack(alignment: .leading, spacing: 4) {
                    Text(journal.title)
                        .font(.title3)
                        .bold()
                    Text(journal.date, style: .date)
                        .font(.subheadline)
                        .italic()
                        .foregroundStyle(.secondary)
                }
                Spacer()
                HStack(alignment: .lastTextBaseline) {
                    VStack {
                        HStack {
                            if journal.entries.count >= 1 {
                                Text("Entry count: ")
                                    .font(.subheadline)
                                    .bold()
                                Text("\(journal.entries.count)")
                                    .font(.subheadline)
                                    .bold()
                            }
                        }
                        Text(journal.date, style: .time)
                            .font(.subheadline)
                            .italic()
                            .foregroundStyle(.secondary)
                    }
                }
            }
            .padding()
            .frame(minWidth: 275)
            .background(
                RoundedRectangle(cornerRadius: 8)
                    .fill(Color(.secondarySystemBackground))
            )
            .overlay(
                RoundedRectangle(cornerRadius: 8)
                    .stroke(.secondary)
            )
        }
        .swipeActions(edge: .leading, allowsFullSwipe: false) {
            if let onEdit {
                Button {
                    onEdit()
                } label: {
                    Label("Edit", systemImage: "pencil")
                }
                .tint(.blue)
            }
        }
    }
}

// Functions for content view
extension ContentView {
    private func deleteEntry(at offsets: IndexSet) {
        for index in offsets {
            context.delete(journals[index])
        }
    }
    
    private func saveEntry(_ newEntry: Journal) {
        if journals.contains(newEntry) {
            if let index = journals.firstIndex(of: newEntry) {
                let entry = journals[index]
                entry.title = newEntry.title
            }
        } else {
            context.insert(newEntry)
        }
        isPresenting = false
        journalBeingEdited = nil
    }
}

#Preview {
    ContentView()
        .modelContainer(for: Journal.self)
}
