//
//  User.swift
//  AdvancedTechniquesLab
//
//  Created by Caleb Mace on 1/5/26.
//

import Foundation
struct User: Identifiable {
    var id: UUID = UUID()
    var username: String
    var password: String
    var passwordHint: String? = nil
}
