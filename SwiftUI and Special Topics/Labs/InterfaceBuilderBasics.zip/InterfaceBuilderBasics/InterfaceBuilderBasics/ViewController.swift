//
//  ViewController.swift
//  InterfaceBuilderBasics
//
//  Created by Caleb Mace on 1/20/26.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var textLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func buttonSelected(_ sender: UIButton) {
        
        textLabel.text = "Button was Clicked!"
    }
    
}

