//
//  State_Spaceship__aka_Stateship_App.swift
//  State Spaceship (aka Stateship)
//
//  Created by Jane Madsen on 9/29/25.
//

import SwiftUI

@main
struct State_Spaceship__aka_Stateship_App: App {
    var body: some Scene {
        WindowGroup {
            SpaceshipScreen()
        }
    }
}
