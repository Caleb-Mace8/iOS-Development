//___FILEHEADER___

import SwiftUI

@main
struct Lab_ListAndForm: App {
    var body: some Scene {
        WindowGroup {
            ListView()
        }
    }
}
