    //
    //  GameView.swift
    //  Project9_GameTracker
    //
    //  Created by Caleb Mace on 12/10/25.
    //
import SwiftUI
import SwiftData

struct GameView: View {
    @Environment(MainRouter.self) var router
    @Environment(\.modelContext) var context
    @State var game: Game
    @State var viewModel: GameViewModel?
    
    init(game: Game) {
        if game.sortingMethod == .Least {
            game.players.sort { $0.score < $1.score }
        } else if game.sortingMethod == .Most {
            game.players.sort { $0.score > $1.score }
        }
        self.game = game
    }
    
    var body: some View {
        VStack {
            if let viewModel {
                VStack {
                    CardDetails(game: game, viewModel: viewModel)
                    VStack {
                        HStack {
                            Text("Players:")
                                .font(.title2.bold())
                                .padding()
                            Spacer()
                        }
                        List {
                            ForEach($game.players, id: \.self) { $player in
                                HStack {
                                    Text(player.name)
                                        .font(.headline.bold())
                                    Spacer()
                                    Stepper("\(player.score)", onIncrement: { player.score += 1 }, onDecrement: { if player.score > 0 { player.score -= 1 }})
                                        .onChange(of: player.score) {
                                            withAnimation(.spring(response: 0.5, dampingFraction: 0.92, blendDuration: 0.1)) {
                                                if game.sortingMethod == .Least {
                                                    game.players.sort { $0.score < $1.score }
                                                } else if game.sortingMethod == .Most {
                                                    game.players.sort { $0.score > $1.score }
                                                }
                                            }
                                        }
                                        .swipeActions(edge: .leading, allowsFullSwipe: false) {
                                            Button {
                                                router.navigateTo(.PlayerAddEdit(player: player, game: game))
                                            } label: {
                                                Image(systemName: "pencil.line")
                                            }
                                            .tint(.blue)
                                        }
                                }
                                .padding()
                            }
                            .onDelete { indexSet in
                                let toDelete = indexSet.map { game.players[$0] }
                                viewModel.delete(players: toDelete)
                            }
                            .onMove { source, destination in
                                withAnimation(.spring(response: 0.35, dampingFraction: 0.85)) {
                                    game.players.move(fromOffsets: source, toOffset: destination)
                                }
                            }
                        }
                        .animation(.spring(response: 0.5, dampingFraction: 0.92, blendDuration: 0.1), value: game.players)
                    }
                }
            } else {
                ProgressView()
            }
        }
        .toolbar {
            ToolbarItem {
                Button {
                    router.navigateTo(.PlayerAddEdit(player: nil, game: game))
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .onAppear {
            viewModel = .init(context: context)
        }
    }
}


struct CardDetails: View {
    @State var game: Game
    @State var viewModel: GameViewModel
    var body: some View {
        VStack {
            VStack(alignment: .leading) {
                Text(game.name)
                    .font(.largeTitle.bold())
                Text(game.date.formatted(date: .abbreviated, time: .omitted))
                    .font(.caption.italic())
                    .foregroundStyle(.secondary)
            }
            .frame(width: 300)
            .padding()
            .background {
                RoundedRectangle(cornerRadius: 20)
                    .foregroundStyle(.thinMaterial)
                    .overlay {
                        RoundedRectangle(cornerRadius: 20)
                            .stroke()
                            .foregroundStyle(.secondary.opacity(0.5))
                    }
            }
        }
    }
}

