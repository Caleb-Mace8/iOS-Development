//
//  Question.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/10/25.
//

struct Question: Equatable {
    var text: String
    var type: ResponseType
    var answers: [Answer]
}
enum ResponseType {
    case single, multiple, ranged
}
