//
//  PersonalityQuizApp.swift
//  PersonalityQuiz
//
//  Created by Caleb Mace on 11/9/25.
//

import SwiftUI

@main
struct PersonalityQuizApp: App {
    var body: some Scene {
        WindowGroup {
            TitleView()
        }
    }
}

// Change buttons in MultipleQuestionSubview to Toggles
// Use a ForEach in SingleQuestionSubview

