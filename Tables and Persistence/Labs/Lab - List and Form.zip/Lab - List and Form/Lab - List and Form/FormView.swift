//
//  FormView.swift
//  Lab - List and Form
//
//  Created by Caleb Mace on 10/7/25.
//

import SwiftUI

struct DetailView: View {
    @Binding var planet: Planet
    var body: some View {
        Form {
            TextField("Name:", text: $planet.name)
            TextField("Type:", text: $planet.type)
            TextField("Distance from the sun (AU):", text: $planet.distanceFromSun)
        }
    }
}
