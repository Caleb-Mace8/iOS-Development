import SwiftUI

@main
struct RandomAPIApp: App {
    var body: some Scene {
        WindowGroup {
           MainView()
        }
    }
}
