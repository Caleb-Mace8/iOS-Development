//
//  LabFile.swift
//  FakeStubMockLAB
//
//  Created by Caleb Mace on 1/26/26.
//
import Foundation

//MARK: - LAB

struct Rep: Codable, Hashable {
    var name: String
    var party: String
    var state: String
    var link: URL?
}

struct Results: Codable {
    var results: [Rep]
}

struct Response: Equatable {
    static func == (lhs: Response, rhs: Response) -> Bool {
        lhs.responseCode == rhs.responseCode
    }
    
    var results: Results?
    var responseCode: Int
}

protocol NetworkService {
    func fetchData(zipcode: Int) async throws -> Response
}

class RepresentativeNetworkService: NetworkService {
    enum RepError: Error {
        case repNotFound
    }
    
    func fetchData(zipcode: Int) async throws -> Response {
        var urlComponents = URLComponents(string: "https://whoismyrepresentative.com/getall_mems.php")!
        urlComponents.queryItems = [
            URLQueryItem(name: "zip", value: "\(zipcode)"),
            URLQueryItem(name: "output", value: "json")
        ]
        
        let (data, response) = try await URLSession.shared.data(from: urlComponents.url!)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw RepError.repNotFound
        }
        
        let decoder = JSONDecoder()
        let repResponse = try decoder.decode(Results.self, from: data)
        return Response(results: Results(results: repResponse.results), responseCode: httpResponse.statusCode)
    }
}

class StubRepresenativeNetworkService: NetworkService {
    func fetchData(zipcode: Int) async throws -> Response {
        if zipcode == 84043 {
            return Response(results: Results(results: [Rep(name: "Caleb", party: "One of them", state: "Utah")]), responseCode: 200)
        } else {
            return Response(results: nil, responseCode: 404)
        }
        
    }
}

class DataFetcher {
    var networkService: NetworkService
    
    init(networkService: NetworkService) {
        self.networkService = networkService
    }
    
    func fetchData(zipcode: Int) async -> Response? {
        try? await networkService.fetchData(zipcode: zipcode)
    }
}
