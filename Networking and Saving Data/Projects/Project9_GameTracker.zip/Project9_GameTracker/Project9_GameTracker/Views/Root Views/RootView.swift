//
//  ContentView.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import SwiftUI
import SwiftData

struct RootView: View {
    @State var viewModel: RootViewViewModel = RootViewViewModel()
    @State var router: MainRouter = MainRouter()
    var body: some View {
        NavigationStack(path: $router.navigationPath) {
            GameListView()
                .navigationDestination(for: MainRouter.Route.self) { route in
                    router.view(for: route)
                }
        }
        .environment(router)
    }
}

#Preview {
    RootView()
        .modelContainer(for: Game.self, inMemory: true)
}
