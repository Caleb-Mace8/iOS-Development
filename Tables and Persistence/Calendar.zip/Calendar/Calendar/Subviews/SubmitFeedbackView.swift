//
//  SubmitFeedbackView.swift
//  Calendar
//
//  Created by Caleb Mace on 11/19/25.
//
import SwiftUI
import Observation

@Observable
class SubmitFeedbackViewModel {
    var feedback1: String = ""
    var feedback2: String = ""
    var feedback3: String = ""
}

struct SubmitFeedbackView: View {
    @Environment(\.dismiss) private var dismiss
    @State private var viewModel = SubmitFeedbackViewModel()
   
    var body: some View {
        @Bindable var model = viewModel
        VStack {
            Form {
                TextField("What went well in today's lesson?", text: $model.feedback1)
                TextField("What are you still confused about?", text: $model.feedback2)
                TextField("What suggestions for activities or changes to the lesson do you have?", text: $model.feedback3)
            }
        }
        .toolbar {
            ToolbarItem {
                Button(action: { dismiss() }) {
                    Text("Save")
                }
            }
        }
        .navigationTitle("Feedback")
        .padding()
    }
}
