//
//  RootView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//

import SwiftUI

struct RootView: View {
    @State var router: DragonRouter = DragonRouter()
    @State var mainRouter: MainRouter = MainRouter()
    
    var body: some View {
        NavigationStack(path: $router.navigationPath) {
            DragonListView(dragons: dragons)
                .navigationDestination(for: DragonRouter.DragonRoute.self) { route in
                    router.view(for: route)
                }
        }
        .environment(router)
    }
}

#Preview {
    RootView(router: DragonRouter())
        .environment(MainRouter())
}
