//
//  FullCalendar.swift
//  Calendar
//
//  Created by Caleb Mace on 11/19/25.
//

import SwiftUI

struct FullCalendar: View {
    @State var viewModel = FullCalendarViewModel()
    var days: [Day]
    
    init(days: [Day]) {
        self.days = days
    }
    
    var body: some View {
        VStack {
            List(days) { day in
                HStack{
                    Text("\(day.lesson.title):")
                        .bold()
                    Text(day.wordOfTheDay)
                    Spacer()
                    VStack {
                        Text(day.date)
                            .italic()
                        Text(day.id)
                            .italic()
                    }
                }
                .clipShape(Rectangle())
                .onTapGesture {
                    viewModel.tapGesture(day: day)
                }
            }
        }
        .sheet(isPresented: $viewModel.isShowingSheet, onDismiss: { viewModel.selectedLesson = Lesson(title: "", description: "") }) {
            if viewModel.selectedLesson != Lesson(title: "", description: "") {
                LessonOutline(lesson: viewModel.selectedLesson)
            }
        }
        .onChange(of: viewModel.selectedLesson) {
            viewModel.showSheet()
        }
    }
}

#Preview {
    FullCalendar(days: DayFetchManager(dayProvider: MockDataProvider()).getDays())
}
