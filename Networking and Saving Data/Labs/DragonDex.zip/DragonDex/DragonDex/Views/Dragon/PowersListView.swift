//
//  PowersList.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//
import SwiftUI

struct PowersListView: View {
    @Environment(MainRouter.self) var mainRouter
    @Environment(DragonRouter.self) var router
    var dragon: Dragon
    
    var body: some View {
        ZStack {
            Color(mainRouter.bgColor)
                .ignoresSafeArea()
            VStack {
                Text("Powers:")
                    .font(Font.largeTitle.bold())
                List(dragon.powers, id: \.self) { power in
                    Text(power)
                }
                .scrollContentBackground(.hidden)
                .background(.clear)
            }
            .padding()
            .background {
                RoundedRectangle(cornerRadius: 20)
                    .foregroundStyle(.thinMaterial)
            }
            .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
            .padding()
        }
    }
}


#Preview {
    RootView(router: DragonRouter())
}
