//
//  DragonRouter.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//
import SwiftUI
import Observation

@Observable
final class DragonRouter {
    var navigationPath = NavigationPath()
    
    enum DragonRoute: Hashable {
        case dragonDetailView(dragon: Dragon)
        case dragonListView(dragons: [Dragon])
        case powersListView(dragon: Dragon)
    }
    
    @ViewBuilder
    func view(for route: DragonRoute) -> some View {
        switch route {
        case .dragonDetailView(dragon: let dragon):
            DragonDetailView(dragon: dragon)
        case .dragonListView(dragons: let dragons):
            DragonListView(dragons: dragons)
        case .powersListView(dragon: let dragon):
            PowersListView(dragon: dragon)
        }
    }
    
    func navigateTo(_ route: DragonRoute) {
        navigationPath.append(route)
    }
}

