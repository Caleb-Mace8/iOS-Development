//
//  CardView.swift
//  BirthdayCardLAB
//
//  Created by Caleb Mace on 1/9/26.
//

import SwiftUI

struct CardView: View {
    var card: Card
    var body: some View {
        GeometryReader { Geometry in
            ZStack {
                if let color = card.color {
                    Color(color)
                        .ignoresSafeArea()
                        .blur(radius: 30)
                } else {
                    Color(Color.secondary)
                        .ignoresSafeArea()
                }
                HStack {
                    VStack(alignment: .leading) {
                        Text("Dear \(card.recipient),")
                            .font(.title.bold())
                            .padding()
                        HStack {
                            Spacer()
                            Text(card.message)
                                .font(.title3)
                                .padding()
                            Spacer()
                        }
                        HStack {
                            Spacer()
                            VStack {
                                Text("Sincerely, \(card.sender)")
                                    .font(.title.bold())
                                    .padding()
                                Text("Sent on: \(card.date.formatted(date: .long, time: .omitted))")
                                    .font(.subheadline.italic())
                                    .foregroundStyle(.secondary)
                            }
                        }
                        if let imageData = card.image {
                            if let image = UIImage(data: imageData) {
                                Image(uiImage: image)
                                    .resizable()
                                    .scaledToFit()
                                    .padding()
                            }
                        }
                    }
                    .padding()
                    .background {
                        RoundedRectangle(cornerRadius: 20)
                            .foregroundStyle(.ultraThinMaterial)
                    }
                }
                .frame(width: Geometry.size.width / 1.25, height: Geometry.size.height / 1.2)
            }
        }
    }
}

