//
//  GradientButtonStyle.swift
//  ButtonsLab
//
//  Created by Caleb Mace on 9/29/25.
//

import SwiftUI

struct Triangle: Shape {
    func path(in rect: CGRect) -> Path {
        var p = Path()
        // Up-pointing isosceles triangle
        p.move(to: CGPoint(x: rect.midX, y: rect.minY))     // top
        p.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))  // bottom-right
        p.addLine(to: CGPoint(x: rect.minX, y: rect.maxY))  // bottom-left
        p.closeSubpath()
        return p
    }
}

struct Tree: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .padding(15)
            .font(.custom("Marker Felt", size: 35))
            .frame(width: 90, height: 110)
            .foregroundColor(.white)
            .background (
                Color(.green)
            )
            .clipShape(Triangle())
        .scaleEffect(configuration.isPressed ? 0.7: 1.0)
        .animation(.easeOut, value: configuration.isPressed)
    }
}

#Preview {
    ContentView()
}
