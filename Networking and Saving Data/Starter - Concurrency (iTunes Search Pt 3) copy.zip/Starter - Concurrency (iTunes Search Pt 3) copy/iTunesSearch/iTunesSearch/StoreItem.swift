//
//  StoreItem.swift
//  iTunesSearch
//
//  Created by Caleb Mace on 11/14/25.
//
import Foundation

struct StoreItem: Codable, Hashable {
    
    var name: String
    var artist: String
    var kind: String
    var description: String
    var artworkURL: String?
    var previewURL: URL?
    
    enum CodingKeys: String, CodingKey {
        case name = "trackName"
        case artist = "artistName"
        case kind = "kind"
        case description = "description"
        case artworkURL = "artworkUrl100"
        case previewURL = "previewUrl"
    }
    
    enum AdditionalKeys: String, CodingKey {
        case description = "longDescription"
    }
    
    init(from decoder: Decoder) throws {
        let values = try decoder.container(keyedBy: CodingKeys.self)
        name = try values.decode(String.self, forKey: .name)
        artist = try values.decode(String.self, forKey: .artist)
        kind = try values.decode(String.self, forKey: .kind)
        artworkURL = try values.decode(String.self, forKey: .artworkURL)
        previewURL = try values.decodeIfPresent(URL.self, forKey: .previewURL)
        
        if let description = try? values.decode(String.self, forKey: .description) {
            self.description = description
        } else {
            let additionalValues = try decoder.container(keyedBy: AdditionalKeys.self)
            self.description = (try? additionalValues.decode(String.self, forKey: .description)) ?? ""
        }
    }
}

struct SearchResponse: Codable {
    var results: [StoreItem]
}
