//
//  ItemCellView.swift
//  iTunesSearch
//
//  Created by Jane Madsen on 11/3/25.
//

import SwiftUI

struct ItemCellView: View {
    let item: StoreItem
    let onPlayButtonPressed: () -> Void
    var body: some View {
        HStack {

            Image(systemName: "photo")
                .resizable()
                .frame(width: 75, height: 75)
                .foregroundColor(.gray)
            VStack(alignment: .leading) {
                Text(item.name)
                    .font(.headline)
                Text(item.artist)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            if let artworkURL = item.artworkURL {
                AsyncImage(url: URL(string: artworkURL))
            } else {
                Image(systemName: "photo")
            }
            if let previewUrl = item.previewURL {
                Button {
                    onPlayButtonPressed()
                } label: {
                    Image(systemName: "play.circle")
                }
            }
        }
        .padding(.vertical, 8)
    }
}
