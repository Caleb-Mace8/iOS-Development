//
//  MainRootView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI

struct MainRootView: View {
    @State var mainViewRouter: MainRouter = MainRouter()
    var body: some View {
        TabView {
            RootView(router: DragonRouter())
                .tabItem {
                    Label("Dragons", systemImage: "lizard.fill")
                }
            RiderRootView(riderRouter: RiderRouter())
                .tabItem {
                    Label("Riders", systemImage: "figure.seated.seatbelt")
                }
        }
        .sheet(isPresented: $mainViewRouter.sheetState) {
            mainViewRouter.view(for: .settingsView)
        }
        .environment(mainViewRouter)
    }
}

#Preview {
    MainRootView(mainViewRouter: MainRouter())
}
