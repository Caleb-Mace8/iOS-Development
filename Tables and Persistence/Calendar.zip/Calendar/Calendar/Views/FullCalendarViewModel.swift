//
//  FullCalendarViewModel.swift
//  Calendar
//
//  Created by Caleb Mace on 11/20/25.
//
import SwiftUI
import Observation

@Observable
class FullCalendarViewModel {
    var isShowingSheet:Bool = false
    var selectedLesson: Lesson = Lesson(title: "", description: "")
    
    func tapGesture(day: Day) {
        selectedLesson = day.lesson
    }
    
    func showSheet() {
        if selectedLesson != Lesson(title: "", description: "") {
            isShowingSheet.toggle()
        }
    }
}
