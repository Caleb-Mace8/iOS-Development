//
//  ContentView.swift
//  Hotel Registration App
//
//  Created by Jane Madsen on 9/26/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        HotelRegistrationScreen()
    }
}

struct HotelRegistrationScreen: View {
    
    @State var firstName:String = ""
    @State var lastName:String = ""
    @State var doorCode:String = ""
    @State var roomNumber:String = ""
    @State var numOfGuests:Int = 0
    @State var lengthOfStay:Int = 0
    @State var nonSmoking:Bool = false
    @State var registrationFeedback:String = ""
    @State var submit:Bool = false
    @State var rating:Double = 0.0
    
    func toggleSubmit() {
        submit.toggle()
    }
    
    var body: some View {
        ZStack {
            Color(.background)
                .ignoresSafeArea()
            VStack {
                    HStack (alignment: .bottom){
                        Text("Mountainland Inn.")
                            .foregroundStyle(Color.background)
                            .font(.custom("Rockwell", size: 30))
                            .padding(5)
                        Image("mountainlandLogo")
                            .resizable()
                            .frame(width: 50, height: 50)
                            .background()
                            .padding(5)
                    }
                    .background() {
                        RoundedRectangle(cornerRadius: 20)
                            .foregroundStyle(.highlight)
                            .frame(width: 500, height: 200)
                            .offset(x: 0, y: -50)
                    }
                    .padding()
                Text("Welcome! Fill out some information for your stay:")
                    .foregroundStyle(Color.background)
                    .font(.custom("Verdana", size: 20))
                    .padding()
                    .background() {
                        RoundedRectangle(cornerRadius: 20)
                            .foregroundStyle(.highlight)
                    }
                    .padding(3)
                HStack {
                    TextField("Enter your first name:", text: $firstName)
                        .font(.custom("Verdana", size: 14))
                        .tint(.text)
                        .textFieldStyle(.roundedBorder)
                    TextField("Enter your last name:", text: $lastName)
                        .font(.custom("Verdana", size: 14))
                        .tint(.text)
                        .textFieldStyle(.roundedBorder)
                }
                .padding()
                HStack {
                    SecureField("Enter your door code:", text: $doorCode)
                        .font(.custom("Verdana", size: 14))
                        .tint(.text)
                        .textFieldStyle(.roundedBorder)
                    TextField("Enter your room number:", text: $roomNumber)
                        .font(.custom("Verdana", size: 14))
                        .tint(.text)
                        .textFieldStyle(.roundedBorder)
                }
                .padding()
            Text("Please select the number of guests in your party.")
                    .foregroundStyle(Color.background)
                    .font(.custom("Verdana", size: 20))
                    .padding()
                    .background() {
                        RoundedRectangle(cornerRadius: 20)
                            .foregroundStyle(.highlight)
                    }
                    .padding(7)
                Picker("Number of guests:", selection: $numOfGuests) {
                    ForEach(1...10, id: \.self) {
                        Text("\($0)")
                    }
                }
                Stepper("Enter the number of nights for your stay: \(lengthOfStay)", value: $lengthOfStay, in: 1...30)
                    .padding()
                    .font(.custom("Verdana", size: 20)).foregroundStyle(Color.text)
                    .font(.custom("Verdana", size: 20))
                Toggle(isOn: $nonSmoking, label: { Text("Smoking")} )
                    .padding()
                    .font(.custom("Verdana", size: 20)).foregroundStyle(Color.text)
                if submit == true {
                    Text("Thank you for booking with us!\nHow would you rate your experience?")
                        .foregroundStyle(Color.background)
                        .font(.custom("Verdana", size: 20))
                        .fixedSize(horizontal: false, vertical: true)
                        .frame(maxWidth: .infinity, alignment: .leading)
                        .padding(20)
                        .background {
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundStyle(.highlight)
                        }
                        .padding(7)
                    Slider(value: $rating, in: 0...5, step: 0.5)
                        .onChange(of: rating) { newValue, oldValue in
                            rating = (newValue * 2).rounded() / 2
                        }
                        .padding()
                    Text("\(rating, specifier: "%.1f")/5 ⭐️'s")
                        .font(.custom("Verdana", size: 20))
                        .foregroundStyle(Color.text)
                        .padding()
                } else {
                    Button(action: toggleSubmit) {
                        Text("Submit")
                            .font(.custom("Verdana", size: 20))
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.highlight)
                    .padding()
                }
                Spacer()
            }
        }
    }
}


#Preview {
    ContentView()
}
