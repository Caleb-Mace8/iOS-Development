    //
//  ContentView.swift
//  iTunesSearch
//
//  Created by Jane Madsen on 11/3/25.
//

import SwiftUI
import Observation

@Observable
class StoreItemListViewModel {
    var items: [StoreItem] = []
    var storeItemController = StoreItemController()
    var searchText = ""
    var selectedMediaType: MediaType = .music
    var previewTask: Task<Void, Never>? = nil
    
    func fetchPreview(item: StoreItem ) {
        if let previewTask {
            previewTask.cancel()
        }

        previewTask = Task {
            // Code to fetch the preview data using the URL
            if let url = item.previewURL {
                do {
                    let previewData = try await storeItemController.fetchPreview(from: url)
                    print("Got a preview! \(previewData.count)")
                } catch {
                    print(error)
                }
            }
            // Once the task is complete, return the stored task value to nil
            previewTask = nil
        }
    }

    func fetchMatchingItems() async {
        if !searchText.isEmpty {
            var mediaSearchText = ""
            switch selectedMediaType {
            case .music:
                mediaSearchText = "music"
            case .movies:
                mediaSearchText = "movie"
            case .books:
                mediaSearchText = "ebook"
            case .apps:
                mediaSearchText = "software"
            }
            let search = searchText.lowercased().replacingOccurrences(of: " ", with: "+")
            // set up query dictionary
            let query = [
                "term": search,
                "media": mediaSearchText,
                "lang": "en-us",
                "limit": "10"
            ]
            // use the item controller to fetch items
            // if successful, use the main queue to set self.items
            // otherwise, print an error to the console
            Task {
                do {
                    try await self.items = storeItemController.fetchItems(matching: query)
                } catch {
                    print(error)
                }
            }
        }
    }
}

struct StoreItemListView: View {
    @State private var viewModel = StoreItemListViewModel()

    var body: some View {
        NavigationStack {
            VStack {
                Picker("Media Type", selection: $viewModel.selectedMediaType) {
                    ForEach(MediaType.allCases, id: \.self) { mediaType in
                        Text(mediaType.rawValue.capitalized)
                    }
                }
                .pickerStyle(SegmentedPickerStyle())
                .padding([.horizontal, .top])

                HStack {
                    TextField("Search...", text: $viewModel.searchText) {
                        // onCommit
                        // When the user hits Return on their keyboard, this closure will trigger
                        Task {
                            await viewModel.fetchMatchingItems()
                        }
                    }
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .submitLabel(.search)
                    .padding([.horizontal, .bottom])
                }
                
                List(viewModel.items, id: \.self) { item in
                    ItemCellView(item: item) {
                        viewModel.fetchPreview(item: item)
                    }
                }
                .listStyle(.plain)
            }
            .navigationTitle("iTunes Search")
            .onAppear {
                Task {
                   await viewModel.fetchMatchingItems()
                }
            }
        }
    }
}

#Preview {
 StoreItemListView()
}
