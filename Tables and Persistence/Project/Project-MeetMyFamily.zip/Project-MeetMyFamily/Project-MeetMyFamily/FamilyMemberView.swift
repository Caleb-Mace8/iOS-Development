//
//  FamilyMemberView.swift
//  Project-MeetMyFamily
//
//  Created by Caleb Mace on 10/10/25.
//
import SwiftUI

struct FamilyMemberView: View {
    
    var familyMember: FamilyMember
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text(familyMember.name.replacingOccurrences(of: " ✅", with: ""))
                .font(.largeTitle)
                .padding()
            Text(familyMember.discription)
                .padding()
            Image(familyMember.image)
                .resizable()
                .scaledToFit()
                .padding(40)
        }
        .navigationBarTitle(Text(familyMember.name))
    }
}
