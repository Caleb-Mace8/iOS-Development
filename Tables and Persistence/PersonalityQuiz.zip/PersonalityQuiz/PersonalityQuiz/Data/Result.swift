//
//  Result.swift
//  PersonalityQuiz
//
//  Created by Caleb Mace on 11/9/25.
//
import SwiftUI

struct Result {
    var title: String
    var description: String
    var image: ImageResource
}
