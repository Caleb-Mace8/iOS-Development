//
//  RiderListView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI

struct RiderListView: View {
    @Environment(MainRouter.self) var mainRouter
    @Environment(RiderRouter.self) var router
    var riders: [Rider]
    
    init(riders: [Rider]) {
        self.riders = riders
    }
    
    var body: some View {
        ZStack {
            Color(mainRouter.bgColor)
                .ignoresSafeArea()
            ScrollView(.vertical, showsIndicators: true) {
                VStack(alignment: .leading, spacing: 16) {
                    LazyVGrid(columns: [
                        GridItem(.flexible(), spacing: 16),
                        GridItem(.flexible(), spacing: 16)
                    ], spacing: 16) {
                        ForEach(riders, id: \.self) { rider in
                            Button {
                                router.navigateTo(.riderDetailView(rider: rider))
                            } label: {
                                RiderCard(rider)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 24)
                }
            }
            .scrollBounceBehavior(.basedOnSize)
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("Riders")
        .toolbar {
            Button {
                mainRouter.sheetState = true
                mainRouter.navigateTo(.settingsView)
            } label: {
                Image(systemName: "gear")
            }
        }
    }
}



struct RiderCard: View {
    var rider: Rider
    
    init(_ rider: Rider) {
        self.rider = rider
    }
    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(colors: [Color.white.opacity(0.9), Color.white.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
                Image(systemName: rider.image)
                    .resizable()
                    .scaledToFit()
                    .padding(20)
                    .foregroundStyle(rider.color)
                    .overlay {
                        Image(systemName: "figure.seated.seatbelt")
                            .resizable()
                            .frame(width: 20, height: 30)
                            .offset(x: 40, y: 40)
                            .foregroundColor(rider.color)
                            .background {
                                Circle()
                                    .frame(width: 35, height: 35)
                                    .offset(x: 40, y: 40)
                                    .foregroundStyle(LinearGradient(colors: [Color.white.opacity(0.9), Color.white.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing))
                                    .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
                            }
                    }
            }
            .frame(width: 110, height: 110)
            
            Text(rider.name)
                .font(.headline.weight(.semibold))
                .foregroundStyle(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.2), lineWidth: 1)
                )
        )
        .shadow(color: .black.opacity(0.08), radius: 12, x: 0, y: 6)
    }
}
