//
//  BirthdayCardLABApp.swift
//  BirthdayCardLAB
//
//  Created by Caleb Mace on 1/9/26.
//

import SwiftUI

@main
struct BirthdayCardLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
