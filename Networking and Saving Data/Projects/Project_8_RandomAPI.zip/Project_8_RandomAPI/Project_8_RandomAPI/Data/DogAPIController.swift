//
//  DogAPIController.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//
import Foundation
import SwiftUI

class DogAPIController: APIController {
    enum DogError: Error {
        case dogNotFound
    }
    
    func fetchData() async throws -> Dog {
        let url = URL(string: "https://dog.ceo/api/breeds/image/random")
        
        let (data, result) = try await URLSession.shared.data(from: url!)
        
        guard let httpResponse = result as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw DogError.dogNotFound
        }
        
        let decoder = JSONDecoder()
        let dogResponse = try decoder.decode(Dog.self, from: data)
        return dogResponse
    }
}
