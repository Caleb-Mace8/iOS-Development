//
//  AdvancedLayoutsandGridsLABApp.swift
//  AdvancedLayoutsandGridsLAB
//
//  Created by Caleb Mace on 1/8/26.
//

import SwiftUI

@main
struct AdvancedLayoutsandGridsLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
