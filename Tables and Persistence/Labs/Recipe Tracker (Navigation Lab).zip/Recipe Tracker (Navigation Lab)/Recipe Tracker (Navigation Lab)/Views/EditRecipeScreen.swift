//
//  EditRecipeScreen.swift
//  Recipe Tracker (Navigation Lab)
//
//  Created by Caleb Mace on 10/8/25.
//

//**Black Diamond:**
//Our users want to be able to edit their existing recipes. Create a screen titled `EditRecipeScreen` with `TextFields` to edit the displayed recipe in `RecipeDetailScreen`; add a button to the toolbar of `RecipeDetailScreen` with a pencil icon to access it. Making it work will require changes in `RecipeDetailScreen` to make your recipe editable.
//
//Add a favorite button to `RecipeDetailView` that, when toggled, moves a recipe from the Discover Screen to MyRecipes and vice versa. You will need to rethink how data is stored in the app to make this possible, perhaps moving your stored lists of recipes up the view hierarchy.
//
//Add a custom path for `NavigationStack` in both `MyRecipesScreen` and `DiscoverScreen`. When a user moves a recipe from Discover to MyRecipes, the root view of the stack should change from Discover to MyRecipes, so that hitting the back button takes them to the view where that recipe is now stored.

import SwiftUI

struct EditRecipeScreen: View {
    var body: some View {
        
    }
}

#Preview {
    EditRecipeScreen()
}
