    //
    //  GameListViewModel.swift
    //  Project9_GameTracker
    //
    //  Created by Caleb Mace on 12/10/25.
    //
import SwiftUI
import Observation
import SwiftData

@Observable
final class GameListViewModel {
    private var context: ModelContext
    var isEditing: Bool = false
    var toDeleteGames: [Game] = []
    var isPresented: Bool = false
    
    init(context: ModelContext) {
        self.context = context
    }
    
    func delete(games: [Game]) {
        for game in games {
            context.delete(game)
        }
    }
    
    func editGame() {
        isEditing.toggle()
        if isEditing == false {
            toDeleteGames.removeAll()
        }
    }
    
    func updateOrder(for games: [Game]) {
        for (index, game) in games.enumerated() {
            game.position = index
        }
        try? context.save()
    }
}
