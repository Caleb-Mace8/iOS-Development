//
//  MainRouter.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI
import Observation

@Observable
final class MainRouter {
    var navigationPath = NavigationPath()
    var bgColor: Color = Color(.secondarySystemBackground)
    var sheetState: Bool = false
    
    enum MainRoute: Hashable {
        case dragonView
        case riderView
        case settingsView
    }
    
    @ViewBuilder
    func view(for route: MainRoute) -> some View {
        switch route {
        case .dragonView:
            RootView()
        case .riderView:
            RiderRootView()
        case .settingsView:
            SettingsView()
        }
    }
    
    func navigateTo(_ route: MainRoute) {
        navigationPath.append(route)
    }
}
