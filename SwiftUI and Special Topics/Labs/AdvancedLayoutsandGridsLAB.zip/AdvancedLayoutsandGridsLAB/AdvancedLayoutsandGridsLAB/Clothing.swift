//
//  Clothing.swift
//  AdvancedLayoutsandGridsLAB
//
//  Created by Caleb Mace on 1/8/26.
//


struct Clothing: Hashable { 
let name: String 
let price: Double 
let size: String 
let color: String 
}
