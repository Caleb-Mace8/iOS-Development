//
//  SOLID.swift
//  Lab - SOLID
//
//  Created by Caleb Mace on 10/29/25.
//

import Foundation

// Protocol Injection

protocol User {
    var name: String { get }
    var email: String { get }
    var id: String { get }
}

class standardUser: User {
    var name: String
    var email: String
    var id: String
    
    init(name: String, email: String, id: String) {
        self.name = name
        self.email = email
        self.id = id
    }
}

class premiumUser: User {
    var name: String
    var email: String
    var id: String
    var profileImage: String = "Default Image"
    
    init(name: String, email: String, id: String) {
        self.name = name
        self.email = email
        self.id = id
    }
}

class admin: User {
    var name: String
    var email: String
    var id: String
    var isAdmin: Bool = true
    
    init(name: String, email: String, id: String) {
        self.name = name
        self.email = email
        self.id = id
    }
}

// Single Responsibility

protocol UserDataStore {
    func saveUser(_ user: User)
    func fetchUser(_ id: String) -> User?
}

class serverUserDatabase: UserDataStore {
    var users: [User] = []
    func saveUser(_ user: any User) {
        users.append(user)
    }
    func fetchUser(_ id: String) -> (any User)? {
        users.first(where: { $0.id == id })
    }
}

class localUserDatabase: UserDataStore {
    var localUsers: [User] = []
    func saveUser(_ user: any User) {
        localUsers.append(user)
    }
    func fetchUser(_ id: String) -> (any User)? {
        localUsers.first(where: { $0.id == id })
    }
}

// Open / Closed Principle & Liskov Substitution

class Post {
    var title: String
    var body: String
    
    init(title: String, body: String) {
        self.title = title
        self.body = body
    }
}

class postServer {
    var posts: [Post] = []
}

class blogPost: Post {
    var datePublished: String
    var blogEntryNumber: Int
    
    init(title: String, body: String, datePublished: String, blogEntryNumber: Int) {
        self.datePublished = datePublished
        self.blogEntryNumber = blogEntryNumber
        super.init(title: title, body: body)
    }
}

class socialMediaPost: Post {
    var datePublished: String
    var image: String
    
    init(title: String, body: String, datePublished: String, image: String) {
        self.datePublished = datePublished
        self.image = image
        super.init(title: title, body: body)
    }
}

class postService {
    let post: Post
    var server = postServer()
    init(post: Post) {
        self.post = post
    }
    
    func postToServer(post: Post) {
        server.posts.append(post)
    }
}

// Interface Segregation Principle

protocol moderator {
    func banUser(_ user: User) -> String
}

extension admin: moderator {
    func banUser(_ user: User) -> String {
        "User \(user.name) has been banned."
    }
}
