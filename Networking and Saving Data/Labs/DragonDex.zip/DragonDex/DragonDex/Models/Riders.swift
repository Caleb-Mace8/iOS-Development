//
//  Riders.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI

enum Element: Hashable {
    case fire
    case ice
    case storm
    case earth
    case shadow
    case light
    case water
    case wind
    case arcane
}

extension Element {
    var displayName: String {
        switch self {
        case .fire: return "Fire"
        case .ice: return "Ice"
        case .storm: return "Storm"
        case .earth: return "Earth"
        case .shadow: return "Shadow"
        case .light: return "Light"
        case .water: return "Water"
        case .wind: return "Wind"
        case .arcane: return "Arcane"
        }
    }
}

struct Rider: Hashable {
    var name: String
    var element: Element
    var age: Int
    var isLegendary: Bool
    var rating: Int // 1-5
    var lore: String
    var color: Color
    var image: String
}

let riders: [Rider] = [
    Rider(
        name: "Aerin Flamebound",
        element: .fire,
        age: 28,
        isLegendary: false,
        rating: 4,
        lore: "Once a blacksmith's apprentice, Aerin bonded with an ember wyrm in the Ashen Crags and now tempers steel with dragonfire.",
        color: .orange,
        image: "flame.fill"
    ),
    Rider(
        name: "Sorin Frostveil",
        element: .ice,
        age: 34,
        isLegendary: false,
        rating: 5,
        lore: "Sorin charts frozen ley lines across the Northern Reach, his dragon's breath carving paths through ancient glaciers.",
        color: .cyan,
        image: "snowflake"
    ),
    Rider(
        name: "Lyra Stormsinger",
        element: .storm,
        age: 24,
        isLegendary: true,
        rating: 5,
        lore: "Said to hear the language of thunder, Lyra conducts tempests like symphonies over the Skyward Steppe.",
        color: .indigo,
        image: "cloud.bolt.rain.fill"
    ),
    Rider(
        name: "Doran Stoneward",
        element: .earth,
        age: 41,
        isLegendary: false,
        rating: 3,
        lore: "Guardian of the Rooted Bastion, Doran's bond with the earth dragon Gneiss keeps the valley from crumbling.",
        color: .green,
        image: "mountain.2.fill"
    ),
    Rider(
        name: "Nyx Umbravale",
        element: .shadow,
        age: 29,
        isLegendary: true,
        rating: 5,
        lore: "A whisper in moonless alleys, Nyx and her shade drake slip between lantern flickers to unmake conspiracies.",
        color: .purple,
        image: "moon.zzz.fill"
    ),
    Rider(
        name: "Aurelian Dawnspear",
        element: .light,
        age: 36,
        isLegendary: false,
        rating: 4,
        lore: "Aurelian patrols the Sunward Spires, his dragon's radiance banishing mists that hide sky-bandits.",
        color: .yellow,
        image: "sun.max.fill"
    ),
    Rider(
        name: "Marin Tidecaller",
        element: .water,
        age: 22,
        isLegendary: false,
        rating: 4,
        lore: "Born to lighthouse keepers, Marin guides leviathans from harbors with songs learned beneath the waves.",
        color: .blue,
        image: "drop.fill"
    ),
    Rider(
        name: "Kestrel Galeheart",
        element: .wind,
        age: 27,
        isLegendary: false,
        rating: 3,
        lore: "Courier of the High Routes, Kestrel and her swift wyrm chart wind-ladders between floating isles.",
        color: .teal,
        image: "wind"
    ),
    Rider(
        name: "Eldrin Spellweft",
        element: .arcane,
        age: 45,
        isLegendary: true,
        rating: 5,
        lore: "Archivist of the Loom, Eldrin rides a runed drake whose scales shimmer with living sigils.",
        color: .mint,
        image: "sparkles"
    )
]
