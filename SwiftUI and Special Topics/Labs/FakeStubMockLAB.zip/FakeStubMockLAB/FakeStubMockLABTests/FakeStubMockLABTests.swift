//
//  FakeStubMockLABTests.swift
//  FakeStubMockLABTests
//
//  Created by Caleb Mace on 1/26/26.
//

import XCTest
@testable import FakeStubMockLAB

@MainActor
class DataFetchTests: XCTestCase {
    
    func testFetchingData() async {
        let networkService = StubRepresenativeNetworkService()
        let dataFetcher = DataFetcher(networkService: networkService)
        let expectedResponse = Response(results: Results(results: [Rep(name: "Caleb", party: "One of them", state: "Utah")]), responseCode: 200)
        
        let result = await dataFetcher.fetchData(zipcode: 84043)
        
        XCTAssertEqual(result, expectedResponse)
    }
    
    func testFetchingBadData() async {
        let networkService = StubRepresenativeNetworkService()
        let dataFetcher = DataFetcher(networkService: networkService)
        
        let result = await dataFetcher.fetchData(zipcode: 12345)
        
        XCTAssertNil(result?.results)
    }
}
