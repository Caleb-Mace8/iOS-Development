//
//  MyModifier.swift
//  ViewModifierExamples
//
//  Created by Toby Youngberg on 9/15/25.
//

import SwiftUI

struct MyModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(5)
            .font(.custom("Bodoni 72 Oldstyle", size: 50))
            .bold()
            .italic()
            .strikethrough()
            .underline()
            .tint(.blue)
            .border(.black)
            .foregroundStyle(Gradient(colors: [.brown, .blue, .red]))
    }
}

struct MyCustomModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .italic()
            .font(.custom("Zapfino", size: 30))
            .background(Color.yellow)
            .frame(width: 500, height: 500)
            .foregroundStyle(.blue)
            .padding()
    }
}
extension View {
    func myModifier() -> some View {
        modifier(MyModifier())
    }
    func myCustomModifier() -> some View {
        modifier(MyCustomModifier())
    }
}

#Preview {
    MyView()
}
