import Foundation

class Calculator {
    var currentValue:Float = 0.0 {
        didSet {
            print("NEW VALUE: \(currentValue)")
        }
    }
    var firstValue:String = ""
    var secondValue:String = ""
    var currentOperator: Operator? = nil
    
    enum Operator {
        case addition, subtraction, multiplication, division
        func apply(_ a: Float, _ b: Float) -> Float {
            switch self {
            case .addition:
                return a + b
            case .subtraction:
                return a - b
            case .division:
                return a / b
            case .multiplication:
                return a * b
            }
        }
    }
    
    enum Action {
        case clear, invert, equals, percentage
    }
    
    func numberButtonPressed(_ number: Int) {
        if currentOperator == nil {
            firstValue.append(String(number))
        } else {
            secondValue.append(String(number))
        }
    }
    func operatorButtonPressed(_ operatorPressed: Operator) {
        switch operatorPressed {
        case .addition:
            currentOperator = .addition
        case .subtraction:
            currentOperator = .subtraction
        case .division:
            currentOperator = .division
        case .multiplication:
            currentOperator = .multiplication
        }
    }
    
    func actionButtonPressed(_ action: Action) {
        switch action {
        case .clear:
            ac()
        case .equals:
            equals()
        case .percentage:
            var percentizedValue: Float
            if currentOperator == nil {
                guard firstValue.isEmpty == false else { return }
                percentizedValue = Float(Int(firstValue)!) / 100
                firstValue = String(percentizedValue)
            } else {
                guard secondValue.isEmpty == false else { return }
                percentizedValue = Float(Int(secondValue)!) / 100
                secondValue = String(percentizedValue)
            }
        case .invert:
            var invertedValue: Float
            if currentOperator == nil {
                guard firstValue.isEmpty == false else { return }
                invertedValue = Float(Int(firstValue)!) * -1
                firstValue = String(invertedValue)
            } else {
                guard secondValue.isEmpty == false else { return }
                invertedValue = Float(Int(secondValue)!) * -1
                secondValue = String(invertedValue)
            }
        }
    }
    
    func ac() {
        currentValue = 0
        firstValue = ""
        secondValue = ""
        currentOperator = nil
    }
    
    func equals() {
        guard let currentOperator = currentOperator,
        let firstValue = Float(firstValue),
        let secondValue = Float(secondValue) else {
            return
        }
        
        let result = currentOperator.apply(firstValue, secondValue)
        currentValue = result
    }
}

let calc = Calculator()
// Addition test with percentage
calc.numberButtonPressed(1)
calc.numberButtonPressed(0)
calc.operatorButtonPressed(.addition)
calc.numberButtonPressed(1)
calc.numberButtonPressed(0)
calc.actionButtonPressed(.percentage)
calc.actionButtonPressed(.equals)
calc.actionButtonPressed(.clear)
//print(currentValue, firstValue, secondValue, operatorValue) will print (0.0   nil) after clear

// Multiplication test
calc.numberButtonPressed(2)
calc.operatorButtonPressed(.multiplication)
calc.numberButtonPressed(8)
calc.actionButtonPressed(.equals)
calc.actionButtonPressed(.clear)

// Division test
calc.numberButtonPressed(9)
calc.operatorButtonPressed(.division)
calc.numberButtonPressed(3)
calc.actionButtonPressed(.equals)
calc.actionButtonPressed(.clear)

// Subtraction test with invert
calc.numberButtonPressed(6)
calc.operatorButtonPressed(.subtraction)
calc.numberButtonPressed(2)
calc.actionButtonPressed(.invert)
calc.actionButtonPressed(.equals)
calc.actionButtonPressed(.clear)
