//
//  SingleQuestionSubview.swift
//  PersonalityQuiz
//
//  Created by Caleb Mace on 11/9/25.
//
import SwiftUI

struct SingleQuestionSubview: View {
    var quizManager: QuizManager
    var question: Question
    @State private var viewModel: SingleQuestionViewModel
    
    init (quizManager:QuizManager, question: Question, viewModel: SingleQuestionViewModel) {
        self.question = question
        self.quizManager = quizManager
        self.viewModel = viewModel
    }
    
    var body: some View {
        VStack {
            Text("Current Question: \(quizManager.questionList.firstIndex(of: question)! + 1)")
                .titleTextStyle()
                .padding()
            Spacer()
            Text(question.text)
                .titleTextStyle()
                .padding()
                .background() {
                    Rectangle()
                        .foregroundColor(.blue)
                        .frame(width:375)
                }
                .padding()
            
            // Answers
            
            ForEach(question.answers) { answer in
                let index = question.answers.firstIndex(of: answer)!
                Button(action: { viewModel.buttonPress(index) }) {
                    Text(question.answers[index].text)
                        .fontStyle()
                }
                .padding()
                .background() {
                    if let selectedAnswer = viewModel.selectedAnswer, selectedAnswer == question.answers[index]  {
                        Group {
                            RoundedRectangle(cornerRadius: 10)
                                .fill(.blue.opacity(0.2))
                        }
                        .overlay {
                            Group {
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(.blue, lineWidth: 2)
                            }
                        }
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                    }
                }
            }
            .padding()
            Spacer()
        }
    }
}
