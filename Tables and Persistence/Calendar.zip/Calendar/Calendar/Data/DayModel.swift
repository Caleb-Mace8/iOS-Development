//
//  DayModel.swift
//  Calendar
//
//  Created by Caleb Mace on 11/13/25.
//
import Foundation

// Template for creating Day objects for the calendar to display

struct Day: Identifiable {
    var date: String
    var id: String
    var lesson: Lesson
    var objective: String
    var readingDue: String
    var assignmentsDue: Assignment?
    var newAssignments: Assignment?
    var codeChallenge: String
    var wordOfTheDay: String
}

struct Assignment: Equatable {
    var title: String
    var description: AttributedString
}

struct Lesson: Equatable {
    var title: String
    var description: AttributedString
}

// protocol allows for when API is added to create a object that provides the data and all functionality will remain the same

protocol DataProvider {
    func getDays() -> [Day]
}
