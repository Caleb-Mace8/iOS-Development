//
//  AdvancedTestingLABTests.swift
//  AdvancedTestingLABTests
//
//  Created by Caleb Mace on 1/28/26.
//

import XCTest
@testable import AdvancedTestingLAB


class AdvancedTestingLABTests: XCTestCase {
    
    func testLogin() {
        var viewModel = ContentViewTestable()
        viewModel.email = "test@example.com"
        viewModel.password = "P@ss123!W0rd"
        
        let loginResult = viewModel.login()
        
        XCTAssertTrue(loginResult)
    }
    
    func testPasswordTooShort() {
        var viewModel = ContentViewTestable()
        viewModel.password = "2Short"
        
        let loginResult = viewModel.login()
        
        XCTAssertFalse(loginResult)
    }
    
    func testPasswordTooLong() {
        var viewModel = ContentViewTestable()
        viewModel.password = "abcdefghijklmnopqrstuvwxyzabcde" // 31 characters long
        
        let loginResult = viewModel.login()
        
        XCTAssertFalse(loginResult)
    }
    
    func testPasswordContainsCapitalandLowercase() {
        var viewModel = ContentViewTestable()
        viewModel.password = "thispasswordshouldntpass"
        
        let loginResult = viewModel.login()
        
        XCTAssertFalse(loginResult)
    }
    
    func testContinueTestingCapitals() {
        var viewModel = ContentViewTestable()
        viewModel.password = "Th1sPasswordShouldPass!"
        
        let loginResult = viewModel.login()
        
        XCTAssertTrue(loginResult)
    }
    
    func testAgainContinueTestingCapitals() {
        var viewModel = ContentViewTestable()
        viewModel.password = "THISSHOULDNOTPASS"
        
        let loginResult = viewModel.login()
        
        XCTAssertFalse(loginResult)
    }
    
    func testNumbersInPassword() {
        var viewModel = ContentViewTestable()
        viewModel.password = "ThisPassword!HasNoNumber"
        
        let loginResult = viewModel.login()
        
        XCTAssertFalse(loginResult)
    }
    
    func testSymbolsInPassword() {
        var viewModel = ContentViewTestable()
        viewModel.password = "NoSymbolsHere1"
        
        let loginResult = viewModel.login()
        
        XCTAssertFalse(loginResult)
    }
    
    func testAllChecksPass() {
        var viewModel = ContentViewTestable()
        viewModel.password = "Th1sIs@ValidPW"
        
        let loginResult = viewModel.login()
        
        XCTAssertTrue(loginResult)
    }
}
