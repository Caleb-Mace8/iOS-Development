//
//  AdvancedTechniquesLabApp.swift
//  AdvancedTechniquesLab
//
//  Created by Caleb Mace on 1/5/26.
//

import SwiftUI

@main
struct AdvancedTechniquesLabApp: App {
    var body: some Scene {
        WindowGroup {
            LoginScreen()
        }
    }
}
