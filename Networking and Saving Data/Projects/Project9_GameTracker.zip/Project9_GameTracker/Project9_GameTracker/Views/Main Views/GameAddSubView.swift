    //
    //  GameEditSubView.swift
    //  Project9_GameTracker
    //
    //  Created by Caleb Mace on 12/10/25.
    //
import SwiftUI
import SwiftData

struct GameAddSubView: View {
    @Query(sort: \Game.date, order: .reverse) var games: [Game]
    @Environment(\.modelContext) var context
    @Environment(\.dismiss) var dismiss
    @State var viewModel: GameAddViewModel?
    @State var game: Game
    var isEditing: Bool = false
    
    init(game: Game?) {
        if let game {
            self.game = game
            isEditing = true
        } else {
            let game: Game = .init(name: "New Game")
            self.game = game
        }
    }
    
    var body: some View {
        VStack {
            if let viewModel {
                if viewModel.isEditing {
                    GameEditView(game: game)
                } else {
                    GameAddView(game: game)
                }
                HStack(alignment: .bottom) {
                    Button {
                        viewModel.saveGame(game, games: games, dismiss: dismiss)
                    } label: {
                        Text("Save")
                            .bold()
                            .frame(width: 100, height: 30)
                    }
                    .buttonStyle(.glassProminent)
                    .tint(.blue)
                    Button {
                        dismiss()
                    } label: {
                        Text("Dismiss")
                            .bold()
                            .frame(width: 100, height: 30)
                    }
                    .buttonStyle(.glass)
                }
                .padding()
            } else {
                ProgressView()
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = GameAddViewModel(context: context, isEditing: isEditing)
            }
        }
        .navigationBarBackButtonHidden()
    }
}


    // MARK: - Subviews

struct GameEditView: View {
    @State var game: Game
    var body: some View {
        VStack {
            HStack {
                Text("Edit:")
                    .font(.title2.bold())
                    .padding()
                Spacer()
            }
            Text(game.name)
                .font(.largeTitle.bold())
                .padding()
            TextField("Name", text: $game.name)
                .textFieldStyle(.roundedBorder)
                .padding()
                .textInputAutocapitalization(.words)
            Text("Sort Players by:")
                .bold()
            Picker("Sorting Method", selection: $game.sortingMethod) {
                ForEach(Game.SortingStyle.allCases) { method in
                    Text(method.rawValue.capitalized)
                }
            }
            .pickerStyle(.palette)
            .padding()
        }
    }
}

struct GameAddView: View {
    @State var game: Game
    @Environment(MainRouter.self) var router
    var body: some View {
        VStack {
            HStack {
                Text("Add:")
                    .font(.title2.bold())
                    .padding()
                Spacer()
            }
            Text(game.name)
                .font(.largeTitle.bold())
                .padding()
            TextField("Name", text: $game.name)
                .textFieldStyle(.roundedBorder)
                .padding()
                .textInputAutocapitalization(.words)
            Text("Sort Players by:")
                .bold()
            Picker("Sorting Method", selection: $game.sortingMethod) {
                ForEach(Game.SortingStyle.allCases) { method in
                    Text(method.rawValue.capitalized)
                }
            }
            .pickerStyle(.palette)
            .padding()
            Button {
                router.navigateTo(.PlayerAddEdit(player: nil, game: game))
            } label: {
                Text("Add player")
                    .font(.title2.bold())
            }
            .buttonStyle(.glassProminent)
            .frame(width: 300, height: 20)
            .padding()
            VStack {
                HStack {
                    Text("Players:")
                        .bold()
                        .padding()
                    Spacer()
                }
                List {
                    ForEach(game.players) { player in
                        Text(player.name)
                            .bold()
                    }
                }
                .listStyle(.insetGrouped)
            }
            .padding()
        }
    }
}
