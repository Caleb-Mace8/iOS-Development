//
//  RiderRouter.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI
import Observation

@Observable
final class RiderRouter {
    var navigationPath = NavigationPath()
    
    enum RiderRoute: Hashable {
        case riderList(riders: [Rider])
        case riderDetailView(rider: Rider)
    }
    
    @ViewBuilder
    func view(for route: RiderRoute) -> some View {
        switch route {
        case .riderList(riders: let riders):
            RiderListView(riders: riders)
        case .riderDetailView(rider: let rider):
            RiderDetailView(rider: rider)
        }
    }
    
    func navigateTo(_ route: RiderRoute) {
        navigationPath.append(route)
    }
}
