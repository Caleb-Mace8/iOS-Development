//
//  SetUpPinScreen.swift
//  Trip Logger
//
//  Created by Jane Madsen on 4/29/25.
//


import SwiftUI
import SwiftData
import MapKit
import PhotosUI

struct SetUpPinScreen: View {
    @State var trip: Trip? = nil
    @State var entry: JournalEntry
    @Environment(\.dismiss) var exitThisScreen
    var dismiss: DismissAction? = nil
    @Environment(\.modelContext) private var context
    @State private var photos: [PhotosPickerItem] = []
    var body: some View {
        VStack {
            Text("Manage Entry")
                .font(.title.bold())
            TextField("Name", text: $entry.name)
                .padding(8)
                .background {
                    RoundedRectangle(cornerRadius: 20)
                        .foregroundStyle(.thinMaterial)
                }
                .overlay {
                    RoundedRectangle(cornerRadius: 20)
                        .stroke()
                        .foregroundStyle(.secondary.opacity(0.5))
                }
                .padding()
            TextField("Description", text: $entry.text)
                .padding(8)
                .background {
                    RoundedRectangle(cornerRadius: 20)
                        .foregroundStyle(.thinMaterial)
                }
                .overlay {
                    RoundedRectangle(cornerRadius: 20)
                        .stroke()
                        .foregroundStyle(.secondary.opacity(0.5))
                }
                .padding()
            DatePicker("Date", selection: $entry.date, displayedComponents: .date)
                .padding()
            PhotoScrollView(journalEntry: entry)
                .frame(height: 150)
                .padding()
        }
        .toolbar {
            ToolbarItem {
                Button {
                    if let trip {
                        trip.journalEntries.append(entry)
                        context.insert(trip)
                    }
                    try? context.save()
                    if let dismiss {
                        dismiss()
                    } else {
                        exitThisScreen()
                    }
                } label: {
                    Text("Save")
                }
            }
        }
    }
}
