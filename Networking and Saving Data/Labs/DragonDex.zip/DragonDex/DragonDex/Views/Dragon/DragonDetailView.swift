//
//  DragonDetailView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//

import SwiftUI

struct DragonDetailView: View {
    @Environment(MainRouter.self) var mainRouter
    @Environment(DragonRouter.self) var router
    var dragon: Dragon
    var body: some View {
        ZStack {
            Color(mainRouter.bgColor)
                .ignoresSafeArea()
            VStack {
                DragonDetailNameCard(dragon: dragon)
                    .padding(.vertical)
                VStack {
                    Text(dragon.lore)
                        .font(Font.body.italic().bold())
                        .padding()
                    Button {
                        router.navigateTo(.powersListView(dragon: dragon))
                    } label: {
                        Text("View Abilies")
                            .foregroundStyle(.black)
                            .font(Font.title.bold())
                            .padding()
                            .background {
                                RoundedRectangle(cornerRadius: 20)
                                    .foregroundStyle(dragon.color)
                            }
                    }
                }
                .padding()
                .background {
                    RoundedRectangle(cornerRadius: 20)
                        .foregroundStyle(.thinMaterial)
                }
                .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
            }
            .padding()
        }
    }
}

struct DragonDetailNameCard: View {
    var dragon: Dragon
    var body: some View {
        HStack {
            VStack {
                Circle()
                    .fill(
                        LinearGradient(colors: [Color.white.opacity(0.9), Color.white.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
                    .overlay {
                        Image(systemName: dragon.image)
                            .resizable()
                            .scaledToFit()
                            .padding(20)
                            .foregroundStyle(dragon.color)
                    }
                    .frame(width: 110, height: 110)
                    .padding()
                HStack {
                    ForEach(0..<5, id: \.self) { i in
                        let isFilled = i < dragon.powerRating
                        Image(systemName: isFilled ? "flame.fill" : "flame")
                            .resizable()
                            .frame(width: 20, height: 25)
                            .foregroundStyle(dragon.color)
                    }
                }
            }
            Spacer()
            VStack {
                Text(dragon.name)
                    .font(Font.largeTitle.bold())
                    .padding()
                Text(dragon.species.displayName)
                    .font(Font.title.italic())
            }
        }
        .padding()
        .background {
            RoundedRectangle(cornerRadius: 20)
                .foregroundStyle(.thinMaterial)
        }
        .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
    }
}

#Preview {
    RootView(router: DragonRouter())
}
