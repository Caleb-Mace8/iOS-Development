//
//  MultipleQuestionSubview.swift
//  PersonalityQuiz
//
//  Created by Caleb Mace on 11/9/25.
//
import SwiftUI

struct MultipleQuestionSubview: View {
    var question: Question
    @Environment(QuizManager.self) var quizManager
    
    @State var bool0 = false
    @State var bool1 = false
    @State var bool2 = false
    @State var bool3 = false
    
    
    init (question: Question) {
        self.question = question
    }
    
    var body: some View {
        VStack {
            Text("Current Question: \(quizManager.questionList.firstIndex(of: question)! + 1)")
                .titleTextStyle()
                .padding()
            Spacer()
            Text(question.text)
                .titleTextStyle()
                .padding()
                .background() {
                    Rectangle()
                        .foregroundColor(.blue)
                        .frame(width:375)
                }
                .padding()
            
            // Answers
            VStack {
                Toggle(isOn: $bool0) {
                    Text(question.answers[0].text)
                }
                .onChange(of: bool0) { oldValue, newVaue in
                    quizManager.selectAnswer(question.answers[0])
                }
                Toggle(isOn: $bool1) {
                    Text(question.answers[1].text)
                }
                .onChange(of: bool1) { oldValue, newVaue in
                    quizManager.selectAnswer(question.answers[1])
                }
                Toggle(isOn: $bool2) {
                    Text(question.answers[2].text)
                }
                .onChange(of: bool2) { oldValue, newVaue in
                    quizManager.selectAnswer(question.answers[2])
                }
                Toggle(isOn: $bool3) {
                    Text(question.answers[3].text)
                }
                .onChange(of: bool3) { oldValue, newVaue in
                    quizManager.selectAnswer(question.answers[3])
                }
            }
            .padding()
            .background() {
                RoundedRectangle(cornerRadius: 20)
                    .foregroundStyle(Color(red: 0.9, green: 0.9, blue: 0.9))
            }
            Spacer()
        }
        Spacer()
    }
}


