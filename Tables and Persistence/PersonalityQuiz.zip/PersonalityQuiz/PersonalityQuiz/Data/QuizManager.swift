//
//  QuizManager.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/10/25.
//
import SwiftUI

@Observable
class QuizManager {
    var selectedAnswers: [Answer] = []
    let questionList: [Question] = [
        Question(
            text: "Which food do you like the most?",
            type: .single,
            answers: [
                Answer(text: "Steak", type: .married),
                Answer(text: "Pie", type: .pie),
                Answer(text: "Caviar", type: .billionaire),
                Answer(text: "Sardines", type: .homeless)
            ]
        ),
        Question(
            text: "Which activities do you enjoy? (Select Multiple)",
            type: .multiple,
            answers: [
                Answer(text: "Reading", type: .billionaire),
                Answer(text: "Spending time with loved ones", type: .married),
                Answer(text: "Dumpster diving", type: .homeless),
                Answer(text: "Eating pie", type: .pie)
            ]
        ),
        Question(
            text: "How much do you enjoy eating pie?",
            type: .ranged,
            answers: [
                Answer(text: "I dislike them", type: .homeless),
                Answer(text: "I don't really like them", type: .married),
                Answer(text: "I enjoy them", type: .billionaire),
                Answer(text: "I love it", type: .pie)
            ]
        ),
        Question(
            text: "What's your ideal weekend? (Select Multiple)",
            type: .multiple,
            answers: [
                Answer(text: "Hosting a gala", type: .billionaire),
                Answer(text: "Family barbecue", type: .married),
                Answer(text: "Baking pies", type: .pie),
                Answer(text: "Exploring back alleys", type: .homeless)
            ]
        ),
        Question(
            text: "Pick a dream home:",
            type: .single,
            answers: [
                Answer(text: "Clifftop mansion", type: .billionaire),
                Answer(text: "Cozy suburban house", type: .married),
                Answer(text: "Bakery above the shop", type: .pie),
                Answer(text: "A well-hidden nook", type: .homeless)
            ]
        ),
        Question(
            text: "Choose a pet:",
            type: .single,
            answers: [
                Answer(text: "Racehorse", type: .billionaire),
                Answer(text: "Golden retriever", type: .married),
                Answer(text: "A pie-loving cat", type: .pie),
                Answer(text: "Street-smart pigeon", type: .homeless)
            ]
        ),
        Question(
            text: "Your go-to beverage?",
            type: .single,
            answers: [
                Answer(text: "Champagne", type: .billionaire),
                Answer(text: "Homemade lemonade", type: .married),
                Answer(text: "Apple cider", type: .pie),
                Answer(text: "Whatever's free", type: .homeless)
            ]
        ),
        Question(
            text: "Pick a vacation:",
            type: .single,
            answers: [
                Answer(text: "Private island retreat", type: .billionaire),
                Answer(text: "Family road trip", type: .married),
                Answer(text: "Tour of famous bakeries", type: .pie),
                Answer(text: "Urban exploring", type: .homeless)
            ]
        )
    ]
    
    func selectAnswer(_ answer: Answer) {
        if selectedAnswers.contains(answer) {
            let index = selectedAnswers.firstIndex(of: answer)!
            selectedAnswers.remove(at: index)
        } else {
            selectedAnswers.append(answer)
        }
    }
    
    func calculateResult() -> Result {
        var married = 0
        var homeless = 0
        var pie = 0
        var billionaire = 0
        for i in selectedAnswers {
            switch i.type {
            case .married:
                married += 1
            case .homeless:
                homeless += 1
            case .pie:
                pie += 1
            case .billionaire:
                billionaire += 1
            }
        }
        let counts = [married, homeless, pie, billionaire]
        switch counts.max()! {
        case married:
            return Result(title: "You're going to get Married!", description: "You said yes to love and now your calendar is full of cake tastings and seating charts. Your partner laughs at your worst jokes, which is the real treasure. Together you’ll master the ancient art of sharing the last fry. And yes, someone’s aunt will absolutely cry at the ceremony—probably happy tears.", image: .marriageResult)
        case homeless:
            return Result(title: "You're Going to be Homeless!", description: "Okay, so your vibe screams ‘adventure mode’ with minimal storage needs. On the bright side, you’ve got five-star reviews for creativity and resourcefulness. You’ll know every free museum day and the best park benches with shade. Don’t worry—this story has a glow-up arc and a surprisingly comfy backpack.", image: .homelessTeen)
        case pie:
            return Result(title: "You're Going to Live in Pie Town, New Mexico!", description: "Your destiny smells like cinnamon and victory. You’ll become a local legend who can identify fillings by sound alone. Friends will measure time by your pie drops instead of clocks. Just remember: with great crust comes great responsibility.", image: .pieTownResult)
        case billionaire:
            return Result(title: "You're Going to be a Billionaire", description: "Your piggy bank just asked for a financial advisor. You invest in big ideas, like homework that does itself and socks that never vanish. Your calendar has more zeros than your math homework. Be kind, tip well, and maybe fund a scholarship for future pie scientists.", image: .BILLIONAIREEEE)
        default:
            return Result(title: "You're Going to Live in Pie Town, New Mexico!", description: "Fate rolled a flaky crust and you landed in the sweetest zip code. You’ll trade small talk for big slices and learn the secret handshake (it’s sticky). Tourists will ask for directions; you’ll point with a fork. Life will be well-balanced—equal parts filling and fun.", image: .pieTownResult)
        }
    }
    
    func nextQuestion(after question: Question) -> Question? {
            let index = questionList.firstIndex(of: question)
            if let index, index < questionList.count - 1 {
                return questionList[index + 1]
            } else {
                return nil
            }
        }
}
