import SwiftUI

@main
struct Lab_Solid: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
