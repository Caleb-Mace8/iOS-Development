    //
    //  ContentView.swift
    //  AdvancedTestingLAB
    //
    //  Created by Caleb Mace on 1/28/26.
    //

import SwiftUI

struct ContentView: View {
    @State var viewModel = ContentViewModel()
    var body: some View {
        VStack {
            Spacer(minLength: 275)
            Text("Sign In")
                .font(.largeTitle.bold())
            HStack {
                Text("Enter Email:")
                    .frame(width: 150)
                    .font(.title3.bold())
                    .padding()
                    .background {
                        Rectangle()
                            .foregroundStyle(.gray.opacity(0.4))
                    }
                TextField("Start typing here...", text: $viewModel.email)
            }
            .background {
                Rectangle()
                    .foregroundStyle(.ultraThinMaterial)
            }
            .overlay {
                Rectangle()
                    .stroke()
                    .foregroundStyle(.black.opacity(0.2))
            }
            Spacer()
            HStack {
                Text("Enter Password:")
                    .frame(width: 150)
                    .font(.title3.bold())
                    .padding()
                    .background {
                        Rectangle()
                            .foregroundStyle(.gray.opacity(0.4))
                    }
                SecureField("Start typing here...", text: $viewModel.password)
                
            }
            .background {
                Rectangle()
                    .foregroundStyle(.ultraThinMaterial)
            }
            .overlay {
                Rectangle()
                    .stroke()
                    .foregroundStyle(.black.opacity(0.2))
            }
            Button {
                viewModel.isLoggedIn = viewModel.login()
            } label: {
                Text("Login")
                    .frame(width: 100, height: 20)
            }
            .buttonStyle(.borderedProminent)
            .padding()
            Spacer(minLength: 275)
        }
        .padding()
        .overlay {
            if viewModel.isLoggedIn {
                Image(systemName: "checkmark.circle.fill")
                    .resizable()
                    .frame(width: 150, height: 150)
                    .foregroundStyle(.green)
            }
        }
    }
}

#Preview {
    ContentView()
}
