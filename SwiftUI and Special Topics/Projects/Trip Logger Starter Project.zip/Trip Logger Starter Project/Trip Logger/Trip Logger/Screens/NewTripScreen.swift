//
//  NewTripView.swift
//  Trip Logger
//
//  Created by Jane Madsen on 4/29/25.
//

import SwiftUI
import SwiftData
import MapKit
import PhotosUI

struct NewTripScreen: View {
    @Environment(\.modelContext) private var context
    @Environment(\.dismiss) private var dismiss
    @State var trip = Trip(name: "")
    private var isDisabled: Bool { trip.name.isEmpty }
    var body: some View {
        NavigationStack {
            VStack {
                Text("Give your trip a name!")
                    .font(.title2)
                    .fontWeight(.bold)
                    .padding(.bottom, 50)
                TextField("Trip Name", text: $trip.name)
                    .padding(8)
                    .background {
                        RoundedRectangle(cornerRadius: 20)
                            .foregroundStyle(.thinMaterial)
                    }
                    .overlay {
                        RoundedRectangle(cornerRadius: 20)
                            .stroke()
                            .foregroundStyle(.secondary.opacity(0.5))
                    }
                    .padding(.bottom, 20)
                HStack {
                    Button {
                        dismiss()
                    } label: {
                        Text("Dismiss")
                            .font(.title2)
                            .frame(width: 150, height: 20)
                    }
                    .buttonStyle(.bordered)
                    NavigationLink {
                        PlacePinScreen(trip: trip, dismiss: dismiss)
                    } label: {
                        Text("Next")
                            .font(.title2)
                            .frame(width: 150, height: 20)
                    }
                    .buttonStyle(.borderedProminent)
                    .disabled(isDisabled)
                }
            }
            .padding()
        }
    }
}

#Preview {
    NewTripScreen()
        .modelContainer(ModelContainer.preview)
}
