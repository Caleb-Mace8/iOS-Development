//
//  Answer.swift
//  Project-PersonalityQuiz
//
//  Created by Caleb Mace on 10/10/25.
//
import UniformTypeIdentifiers

struct Answer: Equatable, Identifiable {
    var id:UUID = UUID()
    var text: String
    var type: FutureType
}
enum FutureType {
    case married, homeless, pie, billionaire
}
