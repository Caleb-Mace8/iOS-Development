//
//  TestDrivenDevelopmentLABApp.swift
//  TestDrivenDevelopmentLAB
//
//  Created by Caleb Mace on 1/23/26.
//

import SwiftUI

@main
struct TestDrivenDevelopmentLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
