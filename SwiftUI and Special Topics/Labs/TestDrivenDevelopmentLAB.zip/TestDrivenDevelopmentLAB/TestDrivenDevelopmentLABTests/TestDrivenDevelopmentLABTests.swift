//
//  TestDrivenDevelopmentLABTests.swift
//  TestDrivenDevelopmentLABTests
//
//  Created by Caleb Mace on 1/23/26.
//
import XCTest
@testable import TestDrivenDevelopmentLAB

class TestPerson: XCTestCase {
    
    func testFullName() {
        let person = Person(firstName: "John", lastName: "Doe", age: 5)
        
        XCTAssertEqual(person.fullName, "John Doe")
    }
    
    func testAge() {
        let person = Person(firstName: "John", lastName: "Doe", age: 5)
        
        var personHasAge = false
        
        if person.fetchAge() > 0 {
            personHasAge = true
        }
        
        XCTAssertEqual(personHasAge, true)
    }
    
    func testCanDriveBeforeAge() {
        let person = Person(firstName: "John", lastName: "Doe", age: 5)
        
        XCTAssertEqual(person.canDrive(), false)
    }
    
    func testCanDriveOnAge() {
        let person = Person(firstName: "John", lastName: "Doe", age: 16)
        
        XCTAssertEqual(person.canDrive(), true)
    }
    
    func testCanDriveAfterAge() {
        let person = Person(firstName: "John", lastName: "Doe", age: 21)
        
        XCTAssertEqual(person.canDrive(), true)
    }
}
