//
//  LoginScreen.swift
//  AdvancedTechniquesLab
//
//  Created by Caleb Mace on 1/5/26.
//

import SwiftUI

struct LoginScreen: View {
    enum LoginState {
        case loading
        case success
        case failure
    }
    
    @State private var user: User = User(username: "", password: "", passwordHint: "It looks like you need a password, try 'Admin123'.. its similar to your username.")
    @State var loginState: LoginState? = nil
    @State private var isVisible: Bool = false
    @State private var isSecure: Bool = true
    
    var body: some View {
        ZStack {
            Color(.secondarySystemFill)
                .ignoresSafeArea()
            VStack {
                
                Spacer()
                
                TextField("Username", text: $user.username)
                    .loginTextFieldStyle
                HStack {
                    if isSecure {
                        SecureField("Password", text: $user.password)
                            .loginTextFieldStyle
                    } else {
                        TextField("Password", text: $user.password)
                            .loginTextFieldStyle
                    }
                    Button {
                        isSecure.toggle()
                    } label: {
                        Image(systemName: isSecure ? "eye.slash" : "eye")
                    }
                    .buttonStyle(LoginButtonStyle())
                }
                Button {
                    guard user.username != "" && user.password != "" else {
                        loginState = .failure
                        return
                    }
                    Task {
                        await tryLogin(user: user)
                    }
                } label: {
                    Text("Login")
                }
                .buttonStyle(ProminentLoginButtonStyle())
                
                // BD: Forgot Password
                Button {
                    withAnimation(.easeInOut) {
                        isVisible = true
                    }
                } label: {
                    Text("Forgot Password?")
                }
                
                if isVisible == true {
                    if let passwordHint = user.passwordHint {
                        Text(passwordHint)
                            .font(.callout.italic())
                            .padding()
                    }
                }
                
                Spacer()
                
                // Login Message
                VStack {
                    if let loginState {
                        switch loginState {
                            case .loading:
                                ProgressView("Signing you in! Please wait...")
                                    .padding()
                                    .font(.title.bold())
                                    .foregroundStyle(.black)
                            case .success:
                                Text("Sucess! You are now logged in!")
                                    .font(.title.bold())
                                    .foregroundStyle(.green)
                            case .failure:
                                Text("There has been an issue signing you in... Please try again.")
                                    .font(.title.bold())
                                    .foregroundStyle(.red)
                        }
                    }
                }
                .padding(.bottom, 50)
            }
            .padding()
        }
    }
    func tryLogin(user: User) async {
        loginState = LoginState.loading
        try? await Task.sleep(nanoseconds: 3_000_000_000)
        let userInfo: User = User(username: "Admin123", password: "Admin123")
        if user.username == userInfo.username && user.password == userInfo.password {
            loginState = LoginState.success
        } else {
            loginState = LoginState.failure
        }
    }
}

#Preview {
    LoginScreen()
}
