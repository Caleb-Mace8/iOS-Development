    //
    //  GameListView.swift
    //  Project9_GameTracker
    //
    //  Created by Caleb Mace on 12/10/25.
    //
import SwiftUI
import SwiftData

struct GameListView: View {
    @Query(sort: \Game.position) var games: [Game]
    @Environment(\.modelContext) var context
    @Environment(MainRouter.self) var router
    @State private var viewModel: GameListViewModel?
    @Environment(\.editMode) var editMode
    @Namespace var gameNamespace
    
    
    var body: some View {
        VStack {
            if let viewModel {
                if games.isEmpty {
                    EmptyListView()
                        .onAppear {
                            editMode?.wrappedValue = .inactive
                        }
                } else {
                    GameList(viewModel: viewModel, games: games)
                }
            } else {
                ProgressView()
            }
        }
        .onAppear {
            if viewModel == nil {
                viewModel = GameListViewModel(context: context)
            }
        }
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                EditButton()
                    .disabled(games.isEmpty)
                    .opacity(games.isEmpty ? 0.4 :  1.0)
            }
            ToolbarItem(placement: .topBarTrailing) {
                Button {
                    router.navigateTo(.gameAddView(game: nil))
                    editMode?.wrappedValue = .inactive
                } label: {
                    Image(systemName: "plus")
                }
            }
        }
        .navigationTitle("Games")
    }
}

    // MARK: - SubViews

struct GameList: View {
    @Environment(MainRouter.self) var router
    let viewModel: GameListViewModel
    let games: [Game]
    
    var body: some View {
        Form {
            ForEach(games) { game in
                GameCard(game)
                    .onTapGesture {
                        router.navigateTo(.gameView(game: game))
                    }
                    .swipeActions(edge: .leading, allowsFullSwipe: false) {
                        Button {
                            router.navigateTo(.gameAddView(game: game))
                        } label: {
                            Image(systemName: "pencil.line")
                        }
                        .tint(.blue)
                    }
            }
            .onDelete { indexSet in
                let toDelete = indexSet.map { games[$0] }
                viewModel.delete(games: toDelete)
            }
            .onMove { source, destination in
                withAnimation(.easeInOut(duration: 0.25)) {
                    var reordered = Array(games)
                    let originalIDs = reordered.map(\.persistentModelID)
                    reordered.move(fromOffsets: source, toOffset: destination)
                    let newIDs = reordered.map(\.persistentModelID)
                    guard newIDs != originalIDs else { return }
                    viewModel.updateOrder(for: reordered)
                }
            }
        }
    }
}

struct EmptyListView: View {
    @Environment(MainRouter.self) var router
    @Environment(\.editMode) var editMode
    var body: some View {
        ZStack {
            Color(.secondarySystemBackground)
                .ignoresSafeArea()
            VStack(alignment: .center) {
                Text("You Have No Games!")
                    .font(.largeTitle.bold())
                HStack {
                    Text("Add Your First Game")
                        .font(.headline.italic())
                    Button {
                        router.navigateTo(.gameAddView(game: nil))
                        editMode?.wrappedValue = .inactive
                    } label: {
                        Image(systemName: "plus.circle.fill")
                            .foregroundStyle(.blue)
                        Text("Add Game")
                            .font(.headline.italic())
                            .foregroundStyle(.blue)
                    }
                }
                .padding(.horizontal, 10)
            }
        }
    }
}

struct GameCard: View {
    var game: Game
    
    init(_ game: Game) {
        self.game = game
    }
    
    var body: some View {
        HStack {
            Image(systemName: "gamecontroller.fill")
                .resizable()
                .frame(width: 55, height: 35)
            Spacer()
            VStack(alignment: .trailing) {
                Text(game.name)
                    .font(.title3.bold())
                    .foregroundColor(.primary)
                    .padding()
                    .contentShape(Rectangle())
                Text(
                    "Date Created: \(game.date.formatted(date: .abbreviated, time: .omitted))"
                )
                .font(.caption2.italic())
                .foregroundColor(.secondary)
                if Date.now
                    .formatted(date: .numeric, time: .omitted) == game.updatedAt
                    .formatted(date: .numeric, time: .omitted) {
                    Text(
                        "Last Edited: " + "\(game.updatedAt.formatted(date: .omitted, time: .shortened))"
                    )
                    .font(.caption2.italic())
                    .foregroundColor(.secondary)
                } else {
                    Text(
                        "Last Edited: " + "\(game.updatedAt.formatted(date: .numeric, time: .shortened))"
                    )
                    .font(.caption2.italic())
                    .foregroundColor(.secondary)
                }
            }
        }
        .padding()
        .contentShape(Rectangle())
        .background {
            RoundedRectangle(cornerRadius: 20)
                .foregroundStyle(.thinMaterial)
        }
        .overlay() {
            RoundedRectangle(cornerRadius: 20)
                .stroke(lineWidth: 2)
                .foregroundStyle(.secondary.opacity(0.5))
        }
        .shadow(radius: 0.08)
    }
}
