//
//  SpaceshipScreen.swift
//  State Spaceship (aka Stateship)
//
//  Created by Jane Madsen on 9/29/25.
//

import SwiftUI
import Observation

@Observable
class ShipComputer {
    var availablePower = 10
    var heading = ""
}

struct SpaceshipScreen: View {
    
    @State var shipComputer = ShipComputer()
    
    var body: some View {
        Form {
            Section("Helm Station") {
                HelmStation()
            }
            
            Section("Weapons Station") {
                WeaponsStation()
            }
            
            Section("Shield Station") {
                ShieldStation()
            }
            
            Section("Engine Station") {
                EngineStation()
            }
            
            Text("Available Power: \(shipComputer.availablePower)")

        }
        .environment(shipComputer)
        .padding()
    }
}

struct HelmStation: View {
    @Environment(ShipComputer.self) var shipComputer
    @State var inChair = false
    var body: some View {
        @Bindable var shipComputer = shipComputer
        HStack {
            CrewChair(crewMember: .dog, inChair: $inChair)
            TextField("Heading", text: $shipComputer.heading)
                .disabled(!inChair)
        }
    }
}


struct WeaponsStation: View {
    @Environment(ShipComputer.self) var shipComputer
    @State var weaponsOn: Bool = false
    @State var powerUsed: Int = 0
    @State var inChair = false
    var body: some View {
        HStack {
            @Bindable var shipComputer = shipComputer
            CrewChair(crewMember: .cat, inChair: $inChair)
            VStack {
                Toggle("Weapons Power: \(powerUsed)", isOn: $weaponsOn)
                    .onChange(of: weaponsOn) { oldValue, newValue in
                        if newValue {
                            shipComputer.availablePower -= 3
                            powerUsed += 3
                        } else {
                            shipComputer.availablePower += 3
                            powerUsed -= 3
                        }
                    }
                Button("Fire!") {
                    if shipComputer.availablePower <= 3 {
                        print("PEW!")
                    }
                }
                .disabled(!weaponsOn)
            }
            .disabled(shipComputer.availablePower < 3)
            .disabled(!inChair)
        }
    }
}

struct ShieldStation: View {
    @Environment(ShipComputer.self) var shipComputer
    @State var powerUsed: Int = 0
    @State var inChair = false
    var body: some View {
        @Bindable var shipComputer = shipComputer
        HStack {
            CrewChair(crewMember: .lizard, inChair: $inChair)
            Stepper("Shield Power: \(powerUsed)", value: $powerUsed, in: 0...10)
                .onChange(of: powerUsed) { oldValue, newValue in
                    let difference = newValue - oldValue
                    shipComputer.availablePower -= difference
                    if shipComputer.availablePower < 0 {
                        powerUsed = oldValue
                    }
                }
                .disabled(!inChair)
        }
    }
}

struct EngineStation: View {
    @Environment(ShipComputer.self) var shipComputer
    @State var powerUsed: Int = 0
    @State var inChair = false
    var body: some View {
        @Bindable var shipComputer = shipComputer
        HStack {
            CrewChair(crewMember: .hare, inChair: $inChair)
            Stepper("Engine Power: \(powerUsed)", value: $powerUsed, in: 0...10)
                .onChange(of: powerUsed) { oldValue, newValue in
                    let difference = newValue - oldValue
                    shipComputer.availablePower -= difference
                    if shipComputer.availablePower < 0 {
                        powerUsed = oldValue
                    }
                }
                .disabled(!inChair)
        }
    }
}

struct CrewChair: View {
    var crewMember: Crew
    @Binding var inChair: Bool
    
    var body: some View {
        Button {
            inChair.toggle()
        } label: {
            if inChair {
                crewMember.icon
            } else {
                Image(systemName: "person.slash")
            }
        }
        .padding(5)
        .background {
            Circle()
                .foregroundStyle(.gray)
        }
    }
}

enum Crew: String {
    case dog
    case cat
    case lizard
    case hare
    
    var icon: Image {
        switch self {
        case .dog:
            Image(systemName: "dog")
        case .cat:
            Image(systemName: "cat")
        case .lizard:
            Image(systemName: "lizard")
        case .hare:
            Image(systemName: "hare")
        }
    }
}

#Preview {
    SpaceshipScreen()
}

