//
//  MainView.swift
//  Calendar
//
//  Created by Caleb Mace on 11/19/25.
//

import SwiftUI
import Observation

@Observable
class MainViewModel {
    let dayFetcher: DayFetchManager
    
    init(dayFetcher: DayFetchManager) {
        self.dayFetcher = dayFetcher
    }
}

// Parent View for the Tabs
struct MainView: View {
    let viewModel: MainViewModel
    var body: some View {
        TabView {
            Tab("Today", systemImage: "calendar.day.timeline.left") {
                DayView(day: viewModel.dayFetcher.getDay())
            }
            Tab("Calendar", systemImage: "calendar") {
                FullCalendar(days: viewModel.dayFetcher.getDays())
            }
        }
    }
}

#Preview {
    MainView(viewModel: MainViewModel(dayFetcher: DayFetchManager(dayProvider: MockDataProvider())))
}
