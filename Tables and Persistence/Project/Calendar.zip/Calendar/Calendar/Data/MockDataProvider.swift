//
//  MockDataProvider.swift
//  Calendar
//
//  Created by Caleb Mace on 11/20/25.
//
import Foundation
// Fake data provider that has the hardcoded days and conforms to the data provider protcol

struct MockDataProvider: DataProvider {
    let days: [Day] = [Day(
        date: "11-14-25",
        id: "ND01",
        lesson: Lesson(title: "Concurrency", description: lessonOutline),
        objective: "- I can define the term concurrency and describe the basics of how a processor executes code on different threads",
        readingDue: "none",
        assignmentsDue: nil,
        newAssignments: Assignment(title: "iTunes Search Part 3", description: iTunesOutline) ,
        codeChallenge: "'Sums in Strings' - Data in Strings",
        wordOfTheDay: "Magic Number"
      ),
      Day(
        date: "11-17-25",
        id: "ND02",
        lesson: Lesson(title: "Review Concurrency", description: lessonOutline),
        objective: "- I can define the term concurrency and describe the basics of how a processor executes code on different threads",
        readingDue: "none",
        assignmentsDue: Assignment(title: "iTunes Search Part 3", description: iTunesOutline),
        newAssignments: nil,
        codeChallenge: "'The Monk and the Stairs' - Interpreting Data",
        wordOfTheDay: "Linter"
      ),
      Day(
        date: "11-18-25",
        id: "ND03",
        lesson: Lesson(title: "Swift Generics", description: lessonOutline),
        objective: " - I can describe the purpose and benefits of using generics, including why Swift requires them unlike other non-type-safe languages",
        readingDue: "none",
        assignmentsDue: Assignment(title: "Generics", description: ""),
        newAssignments: nil,
        codeChallenge: "'Is It Uppercase?' - String Methods",
        wordOfTheDay: "Asynchronous"
      )]
    func getDays() -> [Day] {
        return days
    }
}

// Markdown Strings

let iTunesOutline: AttributedString = try! AttributedString(markdown: """
# Concurrency Lab Requirements - Due Nov 17, 2025 #
 
 ## iTunes Search (Part 3) ##
 
 ### Objective ###
 The objective of this lab is to integrate your iTunes Search network requests into an actual app and apply the lessons you’ve learned about concurrency to the project. You’ll create an app that will allow the user to search for different media types and view the results in a table view. To improve the performance of the table view, you’ll also learn how to update the size of the URL cache to temporarily save images.

 In the iOS Development Repo, open the starter project called “Concurrency (iTunes Search Part 3).” The app includes an initial view with a list view for listing search results, a search bar for entering a query, and a segmented picker for narrowing the search results to a particular media type.

 The `StoreItemListViewModel` class has placeholder properties and functions that handle the search bar and segmented picker and display a list of items in the table view. Before continuing with the following steps, take a moment to review the project’s code to understand how the app is set up.
""")

let lessonOutline: AttributedString = try! AttributedString(markdown: """
## Lesson Outline

 - Cover _Swift Data Collections 2.6: Concurrency_

 Suggested Activities:
 - This lesson relies heavily on the previous two lessons, so spend extra time reviewing them before moving on to this chapter.
 - Review how a multi core processor works, what threads are, what race conditions are, and why we need to think about the order functions are executed.
   - One fun activity could be having students roleplay as a processor. Have one group of four students compete against an individual student to complete a list of math problems and use this as an analogy for concurrency.
 - Have students visually annotate or diagram the code on page 459. Screenshot of what this might look like in Freeform is included below. Encourage students to annotate as much information as possible (and is still relevant to the lesson).
""")
