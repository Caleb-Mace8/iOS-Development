//
//  SettingsView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//

import SwiftUI

struct SettingsView: View {
    @Environment(MainRouter.self) var mainRouter
    
    var body: some View {
        NavigationStack {
            ZStack {
                Color(mainRouter.bgColor)
                    .ignoresSafeArea()
                VStack {
                    List {
                        ColorPicker("Background Color", selection: Binding<Color>(get: { mainRouter.bgColor }, set: { mainRouter.bgColor = $0 }))
                            .padding()
                    }
                    .scrollContentBackground(.hidden)
                    .background(.clear)
                }
                .padding()
            }
            .navigationTitle(Text("Settings"))
        }
    }
}


#Preview {
    RootView(router: DragonRouter())
}
