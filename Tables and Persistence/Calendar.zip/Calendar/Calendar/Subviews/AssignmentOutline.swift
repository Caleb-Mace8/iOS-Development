//
//  AssignmentOutline.swift
//  Calendar
//
//  Created by Caleb Mace on 11/19/25.
//

import SwiftUI

struct AssignmentOutline: View {
    @State private var assignment: Assignment
    
    init(assignment: Assignment) {
        self.assignment = assignment
    }
    
    var body: some View {
        VStack {
            Text(assignment.title)
                .font(.largeTitle)
                .padding()
            Text(assignment.description)
                .padding()
            Button(action: {}) {
                Text("Mark Complete")
            }
            .buttonStyle(.glassProminent)
        }
    }
}

#Preview {
    AssignmentOutline(assignment: .init(title: "iTunes Search Pt. 3", description: iTunesOutline))
}
