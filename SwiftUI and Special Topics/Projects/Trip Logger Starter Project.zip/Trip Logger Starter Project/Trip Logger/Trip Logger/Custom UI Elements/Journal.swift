//
//  Journal.swift
//  Trip Logger
//
//  Created by Jane Madsen on 4/29/25.
//


import SwiftUI
import SwiftData
import MapKit
import PhotosUI

struct Journal: View {
    @Binding var journalEntry: JournalEntry?
    @State var isPresented: Bool = false
    var body: some View {
        NavigationStack {
            JournalTopBar(journalEntry: $journalEntry, isPresented: $isPresented)
                .padding()
            
            if let journalEntry {
                Text(journalEntry.date.formatted(date: .abbreviated, time: .omitted))
                    .font(.headline)
                Text(journalEntry.text)
                    .font(.body)
                
                PhotoScrollView(journalEntry: journalEntry)
            }
        }
        .sheet(isPresented: $isPresented, onDismiss: { isPresented = false }) {
            if let journalEntry {
                SetUpPinScreen(trip: journalEntry.trip ?? nil, entry: journalEntry)
            }
        }
    }
}



struct JournalTopBar: View {
    @Binding var journalEntry: JournalEntry?
    @Binding var isPresented: Bool
    
    var body: some View {
        HStack {
            Button("Edit") {
                // TODO: Add ability to edit journal entries
                isPresented = true
            }
            .disabled(journalEntry == nil)
            
            Spacer()
            
            Text(journalEntry?.name ?? "Journal")
                .font(.title)
            
            Spacer()
            
            Button("Dismiss") {
                journalEntry = nil
            }
        }
    }
}
