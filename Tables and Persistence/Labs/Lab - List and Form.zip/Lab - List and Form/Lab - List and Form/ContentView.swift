//
//  ContentView.swift
//  Lab - List and Form
//
//  Created by Caleb Mace on 10/7/25.
//

import SwiftUI

struct ListView: View {
    @State var planets: [Planet] = [
        Planet(name: "Mercury", type: "Terrestrial", distanceFromSun: "0.39"),
        Planet(name: "Neptune", type: "Ice Giant", distanceFromSun: "30.07"),
        Planet(name: "Saturn", type: "Gas Giant", distanceFromSun: "9.58"),
        Planet(name: "Earth", type: "Terrestrial", distanceFromSun: "1"),
        Planet(name: "Mars", type: "Terrestrial", distanceFromSun: "1.52")
    ]
    
    var body: some View {
        NavigationStack {
            Text("Planets")
                .font(.headline)
                .bold()
            List($planets) { $planet in
                NavigationLink(destination: DetailView(planet: $planet)) {
                    HStack {
                        Image(systemName: "globe")
                            .foregroundStyle(.black)
                        VStack(alignment: .leading) {
                            Text(planet.name)
                                .font(.headline)
                            HStack(spacing: 8) {
                                Text(planet.type)
                                    .foregroundStyle(.secondary)
                                Text("·")
                                    .foregroundStyle(.secondary)
                                Text(planet.distanceFromSun)
                                    .foregroundStyle(.secondary)
                            }
                            .font(.subheadline)
                        }
                        Spacer()
                    }
                }
            }
        }
    }
}


#Preview("ListView") {
    ListView()
}
