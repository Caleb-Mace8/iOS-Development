//
//  RepresentativesViewModel.swift
//  Project_8_RandomAPI
//
//  Created by Caleb Mace on 11/21/25.
//
import Foundation
import Observation

@Observable
class RepresentativesViewModel {
    let apiController = RepAPIController()
    var zipCode: String = ""
    var representatives: [Rep] = []
    
    func fetchRepresentatives() async {
        do {
            self.representatives = try await apiController.fetchData(matching: zipCode)
        } catch {
            print(error)
        }
    }
}
