//
//  PlayerAddEditViewModel.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import SwiftUI
import Observation
import SwiftData

@Observable
final class PlayerAddEditViewModel {
    private var context: ModelContext
    
    init(context: ModelContext) {
        self.context = context
    }
    
    func save(newPlayer: Player, players: [Player], dismiss: DismissAction) {
        if players.contains(newPlayer) {
            if let player = players.firstIndex(of: newPlayer) {
                let player = players[player]
                player.name = newPlayer.name
            }
        } else {
            context.insert(newPlayer)
        }
        dismiss()
    }
}
