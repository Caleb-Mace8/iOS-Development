//
//  CalendarApp.swift
//  Calendar
//
//  Created by Caleb Mace on 11/13/25.
//

import SwiftUI

@main
struct CalendarApp: App {
    var body: some Scene {
        WindowGroup {
            MainView(viewModel: MainViewModel(dayFetcher: DayFetchManager(dayProvider: MockDataProvider())))
        }
    }
}
