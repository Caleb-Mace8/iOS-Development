//
//  ContentView.swift
//  FishingForAPIs_LAB
//
//  Created by Caleb Mace on 2/5/26.
//

import SwiftUI
import SafariServices


struct SafariView: UIViewControllerRepresentable {
    let url: URL

    func makeUIViewController(context: Context) -> SFSafariViewController {
        SFSafariViewController(url: url)
    }

    func updateUIViewController(_ uiViewController: SFSafariViewController, context: Context) { }
}

struct ContentView: View {
    @State private var showSafari = false

    var body: some View {
        VStack {
            Text("Open the Website")
                .font(.title.bold())

            Button("Press me!") {
                showSafari = true
            }
            .buttonStyle(.borderedProminent)
        }
        .padding()
        .sheet(isPresented: $showSafari) {
            SafariView(url: URL(string: "https://www.amazon.com")!)
        }
    } 
}

#Preview {
    ContentView()
}
