//
//  ContentView.swift
//  Project7 - RandomAPI
//
//  Created by Caleb Mace on 11/20/25.
//
import SwiftUI

struct DogListView: View {
    @State var viewModel = DogListViewViewModel(dogAPIFetcher: DogAPIController())

    var body: some View {
        NavigationStack {
            VStack {
                AsyncImage(url: viewModel.currentDog.image) { image in
                        image.resizable()
                    } placeholder: {
                        ProgressView()
                    }
                    .frame(width: 200, height: 200)
                    .padding()
                TextField("Name", text: $viewModel.currentDog.name)
                    .textFieldStyle(.roundedBorder)
                    .padding()
                List($viewModel.dogs) { $dog in
                    NavigationLink() {
                        DogEditView(dog: $dog)
                    } label: {
                        HStack {
                            AsyncImage(url: dog.image) { image in
                                image.resizable()
                            } placeholder: {
                                ProgressView()
                            }
                            .frame(width: 40, height: 40)
                            .padding()
                            Text(dog.name)
                                .font(.custom("system", size: 18))
                                .bold()
                        }
                    }
                }
            }
            .navigationTitle("Dogs")
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        if viewModel.currentDog.name != "" {
                            viewModel.dogs.append(viewModel.currentDog)
                            Task {
                                do {
                                    viewModel.currentDog = try await viewModel.fetchDogs()
                                } catch {
                                    print(error)
                                }
                            }
                        }
                    } label: {
                        Text("Save /")
                            .font(.custom("system", size: 26))
                            .bold()
                        Image(systemName: "plus")
                            .foregroundStyle(Color(.black))
                    }
                }
            }
        }
        .task {
            do {
                viewModel.currentDog = try await viewModel.fetchDogs()
            } catch {
                print(error)
            }
        }
    }
}

#Preview {
    DogListView()
}
