//
//  RepAPIController.swift
//  Project_8_RandomAPI
//
//  Created by Caleb Mace on 11/21/25.
//
import Foundation

class RepAPIController {
    enum RepError: Error {
        case repNotFound
    }
    
    func fetchData(matching zipCode: String) async throws -> [Rep] {
        var urlComponents = URLComponents(string: "https://whoismyrepresentative.com/getall_mems.php")!
        urlComponents.queryItems = [
            URLQueryItem(name: "zip", value: zipCode),
            URLQueryItem(name: "output", value: "json")
        ]
        
        let (data, response) = try await URLSession.shared.data(from: urlComponents.url!)
        
        guard let httpResponse = response as? HTTPURLResponse, httpResponse.statusCode == 200 else {
            throw RepError.repNotFound
        }
        
        let decoder = JSONDecoder()
        let repResponse = try decoder.decode(Results.self, from: data)
        return repResponse.results
    }
}
