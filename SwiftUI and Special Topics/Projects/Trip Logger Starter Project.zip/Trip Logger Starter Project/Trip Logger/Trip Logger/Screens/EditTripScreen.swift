//
//  EditTripScreen.swift
//  Trip Logger
//
//  Created by Caleb Mace on 1/14/26.
//

import SwiftUI

struct EditTripScreen: View {
    @State var trip: Trip
    var dismiss: DismissAction
    @Environment(\.dismiss) var dismissSheet
    @Environment(\.modelContext) var context
    var body: some View {
        NavigationStack {
            VStack {
                Text("Edit Trip")
                    .font(.largeTitle.bold())
                HStack {
                    Text("Change trip name:")
                        .font(.title3.bold())
                    TextField("Trip Name", text: $trip.name)
                        .padding(8)
                        .background {
                            RoundedRectangle(cornerRadius: 20)
                                .foregroundStyle(.thinMaterial)
                        }
                        .overlay {
                            RoundedRectangle(cornerRadius: 20)
                                .stroke()
                                .foregroundStyle(.secondary.opacity(0.5))
                        }
                }
                HStack {
                    Text("Add more Entries")
                        .font(.title3.bold())
                    NavigationLink {
                        PlacePinScreen(trip: trip, dismiss: dismissSheet)
                    } label: {
                        Text("Add pins")
                    }
                    .buttonStyle(.borderedProminent)
                }
                VStack {
                    List {
                        ForEach(trip.journalEntries) { entry in
                            NavigationLink {
                                SetUpPinScreen(entry: entry)
                            } label: {
                                Text(entry.name)
                                    .font(.title2.bold())
                            }
                        }
                        .onDelete { indexSet in
                            let toDelete = indexSet.map { trip.journalEntries[$0] }
                            for entry in toDelete {
                                context.delete(entry)
                            }
                        }
                    }
                }
                HStack {
                    Text("Delete trip")
                        .font(.title3.bold())
                        .foregroundStyle(.red)
                    Button {
                        context.delete(trip)
                        dismissSheet()
                        dismiss()
                    } label: {
                        Text("Delete")
                    }
                    .buttonStyle(.borderedProminent)
                    .tint(.red)
                }
            }
            .padding()
        }
    }
}
