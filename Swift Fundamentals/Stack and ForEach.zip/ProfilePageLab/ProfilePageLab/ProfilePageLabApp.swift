//
//  ProfilePageLabApp.swift
//  ProfilePageLab
//
//  Created by Caleb Mace on 9/25/25.
//

import SwiftUI

@main
struct ProfilePageLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
