//
//  PlacePinScreen.swift
//  Trip Logger
//
//  Created by Jane Madsen on 4/29/25.
//


import SwiftUI
import SwiftData
import MapKit
import PhotosUI

struct PlacePinScreen: View {
    @State var trip: Trip
    var dismiss: DismissAction
    @State var coordinate: CLLocationCoordinate2D? = nil
    var body: some View {
        VStack {
            MapReader { reader in // Allows conversion of a touch gesture into coordinates
                Map {
                    // TODO: Display the pin the user placed
                    if let coordinate {
                        Marker("", coordinate: coordinate)
                    }
                }
                .simultaneousGesture(SpatialTapGesture()
                              .onEnded { event in
                                let location = event.location
                                placePin(reader: reader, location: location)
                              }
                          )
            }
        }
        .navigationTitle("Place a Pin")
        .toolbar {
            ToolbarItem {
                NavigationLink {
                    if let coordinate {
                        SetUpPinScreen(
                            trip: trip, entry: .init(location: Location(
                            latitude: coordinate.latitude,
                            longitude: coordinate.longitude
                            )), dismiss: dismiss)
                    }
                } label: {
                    Text("Next")
                }
                .disabled(coordinate == nil)
            }
        }
    }
    
    func placePin(reader: MapProxy, location: CGPoint) {
        if let tappedCoordinate = reader.convert(location, from: .local) {
            coordinate = tappedCoordinate
        }
    }
}
