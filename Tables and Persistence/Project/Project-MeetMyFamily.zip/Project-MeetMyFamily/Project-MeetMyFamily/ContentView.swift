//
//  ContentView.swift
//  Project-MeetMyFamily
//
//  Created by Caleb Mace on 10/10/25.
//

import SwiftUI

struct ContentView: View {
    
    @State var family: [FamilyMember] = [
        FamilyMember(
            name: "Caleb" ,
            age: 17,
            relationship: "Me",
            image: "me",
            discription: "Caleb is a 17-year-old student who’s passionate about iOS development and design. When he’s not coding, he enjoys playing guitar, hanging out with friends, and exploring new ideas."
        ),
        FamilyMember(
            name: "Tiffanie",
            age: 52,
            relationship: "Mother",
            image: "mom",
            discription: "Tiffanie is a 52-year-old mother who loves to read, cook, and spend time with her family. She’s a great listener and always has a smile on her face."
        ),
        FamilyMember(
            name: "Wade",
            age: 56,
            relationship: "Father",
            image: "dad",
            discription: "Wade is a 56-year-old father who enjoys woodworking, hiking, and cheering on his family’s pursuits. He’s known for his patience, practical advice, and can-do attitude."
        ),
        FamilyMember(
            name: "Sookie",
            age: 5,
            relationship: "Pet - Cat",
            image: "sookie",
            discription: "Sookie is a playful and curious tabby who loves sunny windowsills and chasing anything that crinkles. She’s affectionate on her own terms and always shows up right at snack time."
        ),
        FamilyMember(
            name: "Babette",
            age: 5,
            relationship: "Pet - Cat",
            image: "babette",
            discription: "Babette is a gentle cuddle-bug with a regal vibe. She prefers cozy blankets, quiet naps, and supervising the household from her favorite perch."
        ),
        FamilyMember(
            name: "Little Foot",
            age: 11,
            relationship: "Pet - Dog",
            image: "littleFoot",
            discription: "Little Foot is a loyal, happy-go-lucky pup who lives for walks, belly rubs, and greeting everyone at the door with a wagging tail."
        )
    ]
    
    @State private var selectedMember: FamilyMember?

    var body: some View {
        NavigationStack {
            List($family) { $member in
                VStack(alignment: .leading) {
                    Text(member.name)
                        .font(.headline)
                    Text("\(member.age), \(member.relationship)")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
                .onTapGesture {
                    selectedMember = member
                    if !member.name.hasSuffix(" ✅") {
                        member.name.append(" ✅")
                    }
                }
            }
            .navigationTitle("My Family")
            .sheet(item: $selectedMember) { member in
                FamilyMemberView(familyMember: member)
            }
        }
    }
}

#Preview {
    ContentView()
}
