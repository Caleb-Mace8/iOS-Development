//
//  Rep.swift
//  Project_8_RandomAPI
//
//  Created by Caleb Mace on 11/21/25.
//
import Foundation

struct Rep: Codable, Hashable {
    var name: String
    var party: String
    var state: String
    var link: URL?
}

struct Results: Codable {
    var results: [Rep]
}
