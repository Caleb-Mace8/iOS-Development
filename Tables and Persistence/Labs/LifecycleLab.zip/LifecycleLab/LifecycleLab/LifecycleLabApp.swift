//
//  LifecycleLabApp.swift
//  LifecycleLab
//
//  Created by Caleb Mace on 10/21/25.
//

import SwiftUI

@main
struct LifecycleLabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
