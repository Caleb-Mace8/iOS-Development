//
//  Person.swift
//  GeometryReaderLAB
//
//  Created by Caleb Mace on 1/6/26.
//

struct Person: Hashable {
    var name: String
    var adjective: String
}


