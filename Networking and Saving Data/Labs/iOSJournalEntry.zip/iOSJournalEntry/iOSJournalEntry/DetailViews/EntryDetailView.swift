//
//  JournalDetailView.swift
//  iOSJournalEntry
//
//  Created by Caleb Mace on 12/2/25.
//
import SwiftUI
import SwiftData

struct EntryDetailView: View {
    @State var entry: Entry
    @Environment(\.dismiss) private var dismiss
    let save: (Entry) -> Void
    
    init(entry: Entry, save: @escaping (Entry) -> Void) {
        self.entry = entry
        self.save = save
    }
    
    var body: some View {
        NavigationStack {
            Form {
                HStack {
                    Text("Title:")
                        .bold()
                        .font(.title3)
                    TextField("Title", text: $entry.title)
                        .padding()
                        .background() {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(.thinMaterial)
                        }
                        .overlay() {
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(style: StrokeStyle(lineWidth: 1))
                                .fill(.secondary)
                        }
                }
                HStack {
                    Text("Body:")
                        .bold()
                        .font(.title3)
                    TextEditor(text: $entry.body)
                        .frame(minHeight: 120)
                        .padding(8)
                        .background() {
                            RoundedRectangle(cornerRadius: 20)
                                .fill(.thinMaterial)
                        }
                        .overlay() {
                            RoundedRectangle(cornerRadius: 20)
                                .stroke(style: StrokeStyle(lineWidth: 1))
                                .fill(.secondary)
                        }
                }
            }
            .navigationTitle(Text(entry.title == "" ? "New Entry" : entry.title))
            .toolbar {
                ToolbarItem {
                    Button(action: {
                        save(entry)
                        dismiss()
                    }) {
                        Text("Save")
                    }
                }
            }
        }
    }
}
