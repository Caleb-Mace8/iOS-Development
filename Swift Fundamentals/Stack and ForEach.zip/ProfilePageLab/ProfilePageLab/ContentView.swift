//
//  ContentView.swift
//  ProfilePageLab
//
//  Created by Caleb Mace on 9/25/25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack{
            Color(red: 0.9, green: 0.9, blue: 0.9)
                .ignoresSafeArea()
            VStack(spacing: 5) {
                VStack(alignment: .leading){
                    Image(systemName: "arrowshape.backward")
                        .resizable()
                        .frame(width: 20, height: 20)
                    HStack(spacing: 30){
                        Image(systemName: "person.crop.circle.fill")
                            .resizable()
                            .frame(width: 70, height: 70)
                        VStack(alignment: .leading){
                            Text("John Doe")
                                .font(.custom("Arial Round MT Bold", size: 40.0))
                            Text("johndoe123@example.com")
                                .font(.custom("Arial Round MT Bold", size: 20.0))
                        }
                    }
                    Spacer()
                }
                VStack {
                    Spacer()
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .frame(width: 390, height: 475)
                            .padding(40)
                        VStack(alignment: .leading) {
                            HStack() {
                                Image(systemName: "bell.fill")
                                    .resizable()
                                    .frame(width: 25, height: 30)
                                    .foregroundStyle(.gray)
                                Text("Notifications")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                                    .foregroundStyle(.gray)
                            }
                            Rectangle()
                                .frame(width: 350, height: 1)
                                .padding(12.5)
                            HStack {
                                Image(systemName: "gear")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(Color(red: 0.3, green: 0.3, blue: 0.3))
                                Text("Settings")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                                    .foregroundStyle(Color(red: 0.3, green: 0.3, blue: 0.3))
                            }
                            Rectangle()
                                .frame(width: 350, height: 1)
                                .padding(12.5)
                            HStack {
                                Image(systemName: "book.fill")
                                    .resizable()
                                    .frame(width: 35, height: 30)
                                    .foregroundStyle(Color(red: 0.3, green: 0.2, blue: 0.2))
                                Text("History")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                                    .foregroundStyle(Color(red: 0.3, green: 0.2, blue: 0.2))
                            }
                            Rectangle()
                                .frame(width: 350, height: 1)
                                .padding(12.5)
                            HStack {
                                Image(systemName: "person")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(.blue)
                                Text("Community")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                                    .foregroundStyle(.blue)
                            }
                            Rectangle()
                                .frame(width: 350, height: 1)
                                .padding(12.5)
                            HStack {
                                Text("💣")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                                Text("Bomb")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                            }
                            Rectangle()
                                .frame(width: 350, height: 1)
                                .padding(12.5)
                            HStack {
                                Image(systemName: "ladybug.slash.circle")
                                    .resizable()
                                    .frame(width: 30, height: 30)
                                    .foregroundStyle(.red)
                                Text("Kill all ladybugs")
                                    .font(.custom("Arial Round MT Bold", size: 30))
                                    .foregroundStyle(.red)
                            }
                        }
                    }
                    HStack {
                        ZStack{
                            HStack{
                                ForEach(1..<4) { index in
                                    RoundedRectangle(cornerRadius: 20)
                                        .fill(.red)
                                        .frame(width: 32, height: 10)
                                }
                            }
                            HStack(){
                                ForEach(1..<4) { index in
                                    Circle()
                                        .fill(.black)
                                        .frame(width: 32, height: 10)
                                }
                            }
                        }
                        Text("Live ladybug reaction")
                    }
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color.white)
                            .frame(width: 350 , height: 50)
                        HStack {
                            Image(systemName: "figure.climbing.circle")
                                .resizable()
                                .frame(width: 25, height: 25)
                                .foregroundStyle(.red)
                            Text("Log out")
                                .foregroundStyle(.red)
                                .font(.custom("Arial Round MT Bold", size: 20))
                        }
                    }
                    HStack {
                        Text("ladybug inc.")
                        Image(systemName: "c.circle")
                            .resizable()
                            .frame(width: 15, height: 15)
                    }
                }
            }
        }
    }
}

#Preview {
    ContentView()
}
