//
//  RepresentativesView.swift
//  Project_8_RandomAPI
//
//  Created by Caleb Mace on 11/21/25.
//
import SwiftUI

struct RepresentativesView: View {
    @State var viewModel = RepresentativesViewModel()
    var body: some View {
        VStack {
            TextField("Enter a zip code to search...", text: $viewModel.zipCode)
                .onSubmit {
                Task{
                    await viewModel.fetchRepresentatives()
                }
            }
                .textFieldStyle(.roundedBorder)
            .padding()
            List(viewModel.representatives, id: \.self) { rep in
                HStack {
                    Text(rep.name)
                        .font(.title)
                        .bold()
                    Spacer()
                    VStack {
                        Text("\(rep.party), \(rep.state)")
                            .font(.subheadline)
                            .italic()
                        if let link = rep.link {
                            Text("\(link)")
                                .font(.custom("sytem", size: 10))
                                .foregroundStyle(.blue)
                                .underline()
                        } else {
                            Text("No Link Found")
                        }
                    }
                }
            }
            .navigationTitle("Representatives Search")
        }
    }
}
