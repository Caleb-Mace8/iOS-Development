//
//  Planet.swift
//  Lab - List and Form
//
//  Created by Caleb Mace on 10/7/25.
//
import SwiftUI

struct Planet: Identifiable, Hashable {
    var id: UUID = UUID()
    var name: String
    var type: String
    var distanceFromSun: String
}
