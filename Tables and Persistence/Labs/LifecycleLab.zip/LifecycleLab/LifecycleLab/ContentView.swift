//
//  ContentView.swift
//  LifecycleLab
//
//  Created by Caleb Mace on 10/21/25.
//

import SwiftUI

struct ContentView: View {
    @Environment(\.scenePhase) var scenePhase
    @State var events = "Events: "
    
    var body: some View {
        NavigationStack {
            Text(events)
            NavigationLink(destination: Text("Hello, World!")
                .onAppear() {
                    events.append("\nAppeared")
                }
                .onDisappear() {
                    events.append("\nDisappeared")
                }) {
                    Text("Second View: ")
                }
        }
        .onChange(of: scenePhase) { _, newPhase in
            if newPhase == .inactive {
                events.append("\nInactive")
            } else if newPhase == .active {
                events.append("\nActive")
            } else if newPhase == .background {
                events.append("\nBackground")
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
