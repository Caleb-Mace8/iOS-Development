//
//  JournalDetailView.swift
//  iOSJournalEntry
//
//  Created by Caleb Mace on 12/3/25.
//
import SwiftUI

struct JournalDetailView: View {
    @State var journal: Journal
    @Environment(\.dismiss) private var dismiss
    let save: (Journal) -> Void
    
    init(journal: Journal, save: @escaping (Journal) -> Void) {
        self.save = save
        self.journal = journal
    }
    
    var body: some View {
        NavigationStack {
            Group {
                VStack(alignment: .leading, spacing: 12) {
                    HStack(alignment: .center, spacing: 8) {
                        Text("Title:")
                            .bold()
                            .font(.title3)
                        TextField("Title", text: $journal.title)
                            .textInputAutocapitalization(.words)
                            .padding(8)
                            .background(
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.thinMaterial)
                            )
                            .overlay(
                                RoundedRectangle(cornerRadius: 20)
                                    .stroke(style: StrokeStyle(lineWidth: 1))
                                    .fill(.secondary)
                            )
                    }
                }
                .padding()
            }
            .toolbar {
                ToolbarItem {
                    Button {
                        save(journal)
                        dismiss()
                    } label: {
                        Text("Save")
                    }
                }
            }
            .navigationTitle(journal.title)
        }
    }
}
