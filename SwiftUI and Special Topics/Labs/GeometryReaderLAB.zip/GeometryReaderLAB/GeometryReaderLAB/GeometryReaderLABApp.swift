//
//  GeometryReaderLABApp.swift
//  GeometryReaderLAB
//
//  Created by Caleb Mace on 1/6/26.
//

import SwiftUI

@main
struct GeometryReaderLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
