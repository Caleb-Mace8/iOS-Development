//
//  ContentView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//

import SwiftUI

struct DragonListView: View {
    @Environment(MainRouter.self) var mainRouter
    @Environment(DragonRouter.self) var router
    var dragons: [Dragon]

    var body: some View {
        ZStack {
            Color(mainRouter.bgColor)
                .ignoresSafeArea()
            ScrollView(.vertical, showsIndicators: true) {
                VStack(alignment: .leading, spacing: 16) {
                    LazyVGrid(columns: [
                        GridItem(.flexible(), spacing: 16),
                        GridItem(.flexible(), spacing: 16)
                    ], spacing: 16) {
                        ForEach(dragons, id: \.self) { dragon in
                            Button {
                                router.navigateTo(.dragonDetailView(dragon: dragon))
                            } label: {
                                DragonCard(dragon)
                            }
                            .buttonStyle(.plain)
                        }
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 24)
                }
            }
            .scrollBounceBehavior(.basedOnSize)
            .scrollContentBackground(.hidden)
        }
        .navigationTitle("Dragons")
        .toolbar {
            Button {
                mainRouter.sheetState = true
                mainRouter.navigateTo(.settingsView)
            } label: {
                Image(systemName: "gear")
            }
        }
    }
}

struct DragonCard: View {
    var dragon: Dragon
    
    init(_ dragon: Dragon) {
        self.dragon = dragon
    }
    var body: some View {
        VStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(
                        LinearGradient(colors: [Color.white.opacity(0.9), Color.white.opacity(0.6)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .shadow(color: .black.opacity(0.05), radius: 8, x: 0, y: 4)
                Image(systemName: dragon.image)
                    .resizable()
                    .scaledToFit()
                    .padding(20)
                    .foregroundStyle(dragon.color)
            }
            .frame(width: 110, height: 110)

            Text(dragon.name)
                .font(.headline.weight(.semibold))
                .foregroundStyle(.primary)
                .lineLimit(1)
                .minimumScaleFactor(0.8)
        }
        .padding(16)
        .frame(maxWidth: .infinity)
        .background(
            RoundedRectangle(cornerRadius: 20, style: .continuous)
                .fill(.ultraThinMaterial)
                .overlay(
                    RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .strokeBorder(Color.white.opacity(0.2), lineWidth: 1)
                )
        )
        .shadow(color: .black.opacity(0.08), radius: 12, x: 0, y: 6)
    }
}

#Preview {
    RootView(router: DragonRouter())
}
