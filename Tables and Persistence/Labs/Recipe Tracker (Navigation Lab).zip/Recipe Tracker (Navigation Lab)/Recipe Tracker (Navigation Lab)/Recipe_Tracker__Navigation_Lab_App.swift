//
//  Recipe_Tracker__Navigation_Lab_App.swift
//  Recipe Tracker (Navigation Lab)
//
//  Created by Jane Madsen on 10/8/25.
//

import SwiftUI

@main
struct Recipe_Tracker__Navigation_Lab_App: App {
    var body: some Scene {
        WindowGroup {
            MainTabView()
        }
    }
}
