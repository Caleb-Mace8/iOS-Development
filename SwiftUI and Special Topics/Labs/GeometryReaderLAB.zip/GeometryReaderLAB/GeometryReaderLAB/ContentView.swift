    //
    //  ContentView.swift
    //  GeometryReaderLAB
    //
    //  Created by Caleb Mace on 1/6/26.
    //

import SwiftUI

struct ContentView: View {
    @Environment(\.horizontalSizeClass) var horizontalSizeClass
    
    var rowCount: Int {
        if horizontalSizeClass == .compact {
            if people.count % 2 != 0 {
                return people.count / 2 + 1
            } else {
                return people.count / 2
            }
        } else {
            if people.count % 3 == 0 {
                return people.count / 3
            } else {
                return people.count / 3 + 1
            }
        }
    }
    
    var colomnCount: Int {
        if horizontalSizeClass == .compact {
            return 2
        } else {
            return 3
        }
    }
    
    let people: [Person] = [
        Person(name: "Ada", adjective: "curious"),
        Person(name: "Bruno", adjective: "brave"),
        Person(name: "Cleo", adjective: "creative"),
        Person(name: "Diego", adjective: "diligent"),
        Person(name: "Elena", adjective: "energetic"),
        Person(name: "Finn", adjective: "friendly"),
        Person(name: "Gia", adjective: "generous"),
    ]
    
    var body: some View {
        GeometryReader { geometry in
            VStack(alignment: .center) {
                ForEach(0..<rowCount, id: \.self) { row in
                    HStack {
                        Spacer()
                        ForEach(0..<colomnCount, id: \.self) { colomn in
                            if row * colomnCount + colomn >= people.count {
                                RoundedRectangle(cornerRadius: 20)
                                    .fill(.clear)
                                    .frame(width: geometry.size.width / CGFloat(colomnCount) - 35, height: 125)
                            } else {
                                VStack {
                                    Image(systemName: "person.circle.fill")
                                        .resizable()
                                        .frame(width: 45, height: 45)
                                        .foregroundStyle(.blue)
                                    Text(people[(row * colomnCount) + colomn].name)
                                        .font(.title2.bold())
                                    Text(people[(row * colomnCount) + colomn].adjective)
                                        .font(.subheadline.italic())
                                }
                                .frame(width: geometry.size.width / CGFloat(colomnCount) - 35, height: 125)
                                .background {
                                    RoundedRectangle(cornerRadius: 20)
                                        .foregroundStyle(.thinMaterial)
                                }
                            }
                        }
                        Spacer()
                    }
                    .frame(width: .infinity)
                }
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
