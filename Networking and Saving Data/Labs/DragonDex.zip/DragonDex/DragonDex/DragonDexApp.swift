//
//  DragonDexApp.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/4/25.
//

import SwiftUI

@main
struct DragonDexApp: App {
    var body: some Scene {
        WindowGroup {
            MainRootView()
        }
    }
}
