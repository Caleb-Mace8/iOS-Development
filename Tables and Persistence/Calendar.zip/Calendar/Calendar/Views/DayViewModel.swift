//
//  DayViewModel.swift
//  Calendar
//
//  Created by Caleb Mace on 11/20/25.
//
import SwiftUI
import Observation

@Observable
class DayViewModel {
    var selectedAssignment:Assignment = Assignment(title: "", description: "")
    var isShowingSheet:Bool = false
    
    func forEachDisplay(key: String, dayInfo: [String: String], day: Day) -> some View {
        if key == "New Assignments", dayInfo[key] != "none" {
            return AnyView(
                Button(action: { self.selectedAssignment = day.newAssignments! }) {
                    Text("\(key):").bold()
                    Text("\(dayInfo[key] ?? "none")").italic()
                }
                .buttonStyle(.glass)
            )
        } else if key == "Assignments due", dayInfo[key] != "none" {
            return AnyView(
                Button(action: { self.selectedAssignment = day.assignmentsDue! }) {
                    Text("\(key):").bold()
                    Text("\(dayInfo[key] ?? "none")").italic()
                }
                .buttonStyle(.glass)
            )
        } else {
            return AnyView(
                HStack {
                    Text("\(key):").bold()
                    Text("\(dayInfo[key] ?? "none")").italic()
                }
            )
        }
    }
}
