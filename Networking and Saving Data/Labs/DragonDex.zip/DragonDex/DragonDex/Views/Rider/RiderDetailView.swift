//
//  RiderDetailView.swift
//  DragonDex
//
//  Created by Caleb Mace on 12/5/25.
//

import SwiftUI

struct RiderDetailView: View {
    @Environment(MainRouter.self) var mainRouter
    @Environment(RiderRouter.self) var router
    var rider: Rider
    
    var body: some View {
        ZStack {
            Color(mainRouter.bgColor)
                .ignoresSafeArea()
            VStack {
                RiderDetailNameCard(rider: rider)
                    .padding(.vertical)
                VStack {
                    Text(rider.lore)
                        .font(Font.body.italic().bold())
                        .padding()
                }
                .padding()
                .background {
                    RoundedRectangle(cornerRadius: 20)
                        .foregroundStyle(.thinMaterial)
                }
                .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
            }
            .padding()
        }
        
    }
}

struct RiderDetailNameCard: View {
    var rider: Rider
    var body: some View {
        HStack {
            VStack {
                Circle()
                    .fill(
                        LinearGradient(colors: [Color.white.opacity(0.9), Color.white.opacity(0.7)], startPoint: .topLeading, endPoint: .bottomTrailing)
                    )
                    .shadow(color: .black.opacity(0.2), radius: 8, x: 0, y: 4)
                    .overlay {
                        Image(systemName: rider.image)
                            .resizable()
                            .scaledToFit()
                            .padding(20)
                            .foregroundStyle(rider.color)
                    }
                    .frame(width: 110, height: 110)
                    .padding()
                HStack {
                    ForEach(0..<5, id: \.self) { i in
                        let isFilled = i < rider.rating
                        Image(systemName: isFilled ? "flame.fill" : "flame")
                            .resizable()
                            .frame(width: 20, height: 25)
                            .foregroundStyle(rider.color)
                    }
                }
            }
            Spacer()
            VStack {
                Text(rider.name)
                    .font(Font.title2.bold())
                    .padding()
                Text("\(rider.isLegendary ? "Legendary": "Rookie")")
                    .font(Font.title.italic())
            }
        }
        .padding()
        .background {
            RoundedRectangle(cornerRadius: 20)
                .foregroundStyle(.thinMaterial)
        }
        .shadow(color: .black.opacity(0.08), radius: 8, x: 0, y: 4)
    }
}
