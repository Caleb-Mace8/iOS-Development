//
//  AdvancedTestingLABApp.swift
//  AdvancedTestingLAB
//
//  Created by Caleb Mace on 1/28/26.
//

import SwiftUI

@main
struct AdvancedTestingLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
