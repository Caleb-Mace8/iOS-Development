//
//  Card.swift
//  BirthdayCardLAB
//
//  Created by Caleb Mace on 1/9/26.
//
import Foundation
import SwiftUI
import PhotosUI

struct Card: Identifiable {
    var id: UUID = UUID()
    var recipient: String
    var sender: String
    var message: String
    var date: Date = Date.now
    var color: Color? = nil
    var image: Data?
    
    init(recipient: String, sender: String, message: String) {
        self.recipient = recipient
        self.sender = sender
        self.message = message
    }
}

@Observable
class CardStore {
    var cards: [Card] = []
}
