//
//  FishingForAPIs_LABApp.swift
//  FishingForAPIs_LAB
//
//  Created by Caleb Mace on 2/5/26.
//

import SwiftUI

@main
struct FishingForAPIs_LABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
