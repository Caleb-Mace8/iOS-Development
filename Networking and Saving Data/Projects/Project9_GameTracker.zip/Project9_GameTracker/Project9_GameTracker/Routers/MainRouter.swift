//
//  MainRouter.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import SwiftUI
import Observation

@Observable
final class MainRouter {
    var navigationPath = NavigationPath()
    
    enum Route: Hashable {
        case gameListView
        case gameAddView(game: Game?)
        case gameView(game: Game)
        case PlayerAddEdit(player: Player?, game: Game)
    }
    
    @ViewBuilder
    func view(for route: Route) -> some View {
        switch route {
        case .gameListView:
            GameListView()
                    .transition(.opacity.combined(with: .scale))
        case .gameAddView(game: let game):
            GameAddSubView(game: game)
                    .transition(.opacity.combined(with: .scale))
        case .gameView(game: let game):
            GameView(game: game)
                    .transition(.opacity.combined(with: .scale))
        case .PlayerAddEdit(player: let player, game: let game):
                PlayerAddEditView(player: player, game: game)
                    .transition(.opacity.combined(with: .scale))
        }
    }
    
    func navigateTo(_ route: Route) {
        navigationPath.append(route)
    }
}
