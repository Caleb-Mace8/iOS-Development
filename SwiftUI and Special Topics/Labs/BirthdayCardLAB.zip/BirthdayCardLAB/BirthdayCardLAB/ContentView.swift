    //
    //  ContentView.swift
    //  BirthdayCardLAB
    //
    //  Created by Caleb Mace on 1/9/26.
    //

import SwiftUI

struct ContentView: View {
    @State var cardHolder = CardStore()
    @State private var isPresenting: Bool = false
    var body: some View {
        NavigationStack {
            ScrollView {
                GeometryReader { geometry in
                    LazyVGrid(
                        columns: [
                            GridItem(.fixed(geometry.size.width / 2)),
                            GridItem(.fixed(geometry.size.width / 2))
                        ]
                    ) {
                        ForEach(cardHolder.cards) { card in
                            NavigationLink {
                                CardView(card: card)
                            } label: {
                                VStack {
                                    Image(systemName: "giftcard")
                                        .resizable()
                                        .frame(width: geometry.size.width / 5, height: geometry.size.width / 5 - 20)
                                    Text("Card to: \(card.recipient)")
                                        .font(.largeTitle.bold())
                                }
                                .padding()
                                .background {
                                    RoundedRectangle(cornerRadius: 20)
                                        .foregroundStyle(.ultraThinMaterial)
                                }
                            }
                        }
                    }
                }
            }
            .toolbar {
                ToolbarItem {
                    Button {
                        isPresenting.toggle()
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .navigationTitle("Cards")
            .sheet(isPresented: $isPresenting) {
                CardEditorView(cardHolder: cardHolder)
            }
        }
    }
}

#Preview {
    ContentView()
}
