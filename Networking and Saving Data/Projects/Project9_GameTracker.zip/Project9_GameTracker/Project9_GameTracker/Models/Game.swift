//
//  Game.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import Foundation
import SwiftData


@Model
final class Game: Identifiable {
    
    enum SortingStyle: String, CaseIterable, Identifiable, Codable {
        case Least
        case Most
        var id: Self { self }
    }
    
    var id: UUID = UUID()
    var name: String
    var sortingMethod: SortingStyle
    @Relationship(deleteRule: .cascade, inverse: \Player.game) var players: [Player]
    var date: Date
    var updatedAt: Date
    var position: Int?
    var complete: Bool = false
    
    init(name: String = "New Game", sortingMethod: SortingStyle = .Most, players: [Player] = [], date: Date = .now, updatedAt: Date = .now, position: Int? = nil) {
        self.name = name
        self.sortingMethod = sortingMethod
        self.players = players
        self.date = date
        self.updatedAt = updatedAt
        self.position = position
    }
}
