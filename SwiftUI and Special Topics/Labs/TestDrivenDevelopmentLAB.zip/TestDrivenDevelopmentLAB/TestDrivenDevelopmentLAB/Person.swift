//
//  Person.swift
//  TestDrivenDevelopmentLAB
//
//  Created by Caleb Mace on 1/23/26.
//
import Foundation

struct Person {
    var firstName: String
    var lastName: String
    var age: Int
    init(firstName: String, lastName: String, age: Int) {
        self.firstName = firstName
        self.lastName = lastName
        self.age = age
    }
    
    var fullName: String {
        return "\(firstName) \(lastName)"
    }
    
    func fetchAge() -> Int {
        return age
    }
    
    func canDrive() -> Bool {
        if age >= 16 {
            return true
        } else {
            return false
        }
    }
}
