//    
//      CustomStyles.swift
//      AdvancedTechniquesLab
//    
//      Created by Caleb Mace on 1/5/26.
//    
import SwiftUI

struct ProminentLoginButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .foregroundColor(.white)
            .padding()
            .frame(width: 380, height: 50)
            .background {
                RoundedRectangle(cornerRadius: 20)
                    .foregroundStyle(Color.buttonColor)
                    .shadow(color: .black.opacity(0.08), radius: 5, x: 10, y: 10)
            }
            .scaleEffect(configuration.isPressed ? 0.9 : 1.0)
    }
}

struct LoginButtonStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label
            .font(.title3.bold())
            .padding(.vertical, 20)
            .foregroundStyle(Color.buttonColor.opacity(configuration.isPressed ? 0.6 : 1.0))
    }
}

struct LoginTextFieldStyle: ViewModifier {
    func body(content: Content) -> some View {
        content
            .font(.custom("Times New Roman", size: 20))
            .padding()
            .frame(width: .infinity, height: 65)
            .background {
                RoundedRectangle(cornerRadius: 20)
                    .foregroundStyle(.ultraThinMaterial)
                    .shadow(color: .black.opacity(0.08), radius: 5, x: 10, y: 10)
            }
            .overlay {
                RoundedRectangle(cornerRadius: 20)
                    .stroke()
                    .foregroundStyle(Color.buttonColor)
            }
            .padding(.vertical, 20)
    }
}

extension Color {
    static let buttonColor = Color(red: 0/255.0, green: 180/255.0, blue: 188/255.0)
}

extension View {
    var loginTextFieldStyle: some View {
        self.modifier(LoginTextFieldStyle())
    }
}

#Preview {
    LoginScreen()
}
