//
//  AnimationLABApp.swift
//  AnimationLAB
//
//  Created by Caleb Mace on 12/8/25.
//

import SwiftUI

@main
struct AnimationLABApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
