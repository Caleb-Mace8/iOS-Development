//
//  SingleQuestionViewModel.swift
//  PersonalityQuiz
//
//  Created by Caleb Mace on 11/11/25.
//
import SwiftUI

@Observable
  class SingleQuestionViewModel {
      let quizManager: QuizManager
      var selectedAnswer: Answer? = nil
      var currentQuestion: Question
      
      init(quizManager: QuizManager, question: Question) {
          self.quizManager = quizManager
          self.currentQuestion = question
      }

      func buttonPress(_ buttonNum: Int) {
          if selectedAnswer == nil {
              selectedAnswer = currentQuestion.answers[buttonNum]
              quizManager.selectAnswer(currentQuestion.answers[buttonNum])
          } else if let selectedAnswer {
              quizManager.selectAnswer(selectedAnswer)
              self.selectedAnswer = currentQuestion.answers[buttonNum]
              quizManager.selectAnswer(currentQuestion.answers[buttonNum])
          }
      }
  }
