//
//  Players.swift
//  Project9_GameTracker
//
//  Created by Caleb Mace on 12/10/25.
//
import Foundation
import SwiftData

@Model
final class Player: Identifiable  {
    var id: UUID = UUID()
    var name: String
    var score: Int
    var game: Game?
    
    init(name: String, game: Game?, score: Int = 0) {
        self.name = name
        self.score = score
        self.game = game
    }
}
